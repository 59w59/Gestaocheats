from typing import Union
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from ..admins.panel_items.bonus_manager import get_register_bonus
from config import ADMINS, ADMIN_CHAT, GRUPO_PUB
from database import cur, save
from utils import create_mention, get_info_wallet, dobrosaldo, is_b_online
from config import BOT_LINK, BOT_LINK_SUPORTE, CANAL_ID, CANAL_LINK, VENCIMENTO

# Criar um cliente Pyrogram
app = Client("meu_bot")
      
notified_users = set()  # Crie um conjunto para armazenar os IDs dos usuários notificados

def is_bot_expired():
    # Ensure the date format is valid
    expiration_date = datetime.strptime('28-02-2025', '%Y-%m-%d')  # Update to a valid date
    return datetime.now() > expiration_date

async def check_expiration(c: Client, user_id: int):
    if is_bot_expired():
        # Enviar mensagem ao admin
        await c.send_message(ADMIN_CHAT, "O bot atingiu a data de vencimento e foi desativado.")
        return True
    return False
  
async def check_user_in_group(c: Client, user_id: int):
    try:
        await c.get_chat_member(CANAL_ID, user_id)
        return True, None  
    except Exception as e:
        if "USER_NOT_PARTICIPANT" in str(e):
            message = "<b>Para acessar esse bot é obrigatório que se inscreva no canal clicando no botão abaixo para poder começar a usar o bot:</b>"
            return False, message
        else:
            print("Error checking user in group: ", e)
            return False, '⚠️ Ocorreu um erro ao verificar sua participação no grupo. Tente novamente mais tarde.'

async def notify_admin_new_user(c: Client, user_id: int, user_name: str, kb: InlineKeyboardMarkup):
    global notified_users
    if user_id not in notified_users:
        admin_message = f"✅ <i>USUÁRIO REGISTRADO!\n├👤 NOME: {user_name}\n└🆔 ID: {user_id}</i>"
        await c.send_message(GRUPO_PUB, admin_message, reply_markup=kb)
        notified_users.add(user_id)  # Adicione o ID do usuário ao conjunto de usuários notificados

# Função para adicionar saldo ao usuário
def add_balance(user_id, amount):
    cur.execute('UPDATE users SET balance = balance + ? WHERE id = ?', (amount, user_id))
    save()

# Função para aplicar o bônus de registro após o cadastro do usuário
def apply_register_bonus(user_id):
    bonus = get_register_bonus()  # Pega o valor do bônus

    if bonus > 0:
        # Verifica se o saldo do usuário é zero (caso seja o primeiro registro)
        cur.execute('UPDATE users SET balance = balance + ? WHERE id = ? AND balance = 0', (bonus, user_id))
        save()

@Client.on_message(filters.command(["start", "menu"]) & filters.private)
@Client.on_callback_query(filters.regex("^start$") & filters.private)
async def start(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id
    user_name = m.from_user.first_name

    if await check_expiration(c, user_id):
        await m.reply("<b>⚠️ O bot está vencido e não pode executar comandos.</b>")
        return
      
    is_in_group, message = await check_user_in_group(c, user_id)
    if not is_in_group:
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton("🔗 Se Inscrever no Canal", url=f"https://t.me/{CANAL_LINK}")]]
        )
        await m.reply_text(message, reply_markup=keyboard)
        return

     # Verifica se o usuário já está registrado; caso contrário, registra
    cur.execute('INSERT OR IGNORE INTO users (id, balance) VALUES (?, ?)', (user_id, 0))
    save()


    rt = cur.execute(
        "SELECT id, balance, balance_diamonds, refer FROM users WHERE id=?", [user_id]
    ).fetchone()

    # Após o registro, aplica o bônus se necessário
    apply_register_bonus(user_id)
  
    if isinstance(m, Message):
        refer = (
            int(m.command[1])
            if (len(m.command) == 2)
            and (m.command[1]).isdigit()
            and int(m.command[1]) != user_id
            else None
        )

        if rt is None:
            cur.execute("INSERT INTO users (id, balance, balance_diamonds, refer) VALUES (?, ?, ?, ?)", (user_id, 0, 0, None))
            set_initial_balance(user_id)
            save()

        if rt[3] is None:
            if refer is not None:
                mention = create_mention(m.from_user, with_id=False)
                cur.execute("UPDATE users SET refer = ? WHERE id = ?", [refer, user_id])
                try:
                    await c.send_message(
                        refer,
                        text=f"🎁 <b>Parabéns, o usuário {mention} se vinculou com seu link de afiliado e você receberá uma porcentagem do que o mesmo adicionar no nosso bot.</b>",
                    )
                except BadRequest:
                    pass
          
        # Notificar o admin sobre o novo usuário
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="🤖 Registre-se", url=f"t.me/{BOT_LINK}?start")],
            ]
        )
        await notify_admin_new_user(c, user_id, user_name, kb)

    is_on = is_b_online()
    status = "✅ Ativar notificação" if is_on else "❌ Desativar notificação"
    reverse = "❌ Desativar notificação" if is_on else "✅ Ativar notificação"
    
    # Verificar se o usuário é administrador
    is_admin = user_id in ADMINS
    
    # Adicionar botão de administrador se o usuário for administrador
    admin_button = [InlineKeyboardButton("Admin Button", callback_data="admin_action")] if is_admin else []

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🛒 Comprar", callback_data="shop"),
                InlineKeyboardButton("📄 Termos de uso", callback_data="termos"),
            ],
            [
                InlineKeyboardButton("🏆 Ranking", callback_data="ranking"), 
                #InlineKeyboardButton("💸 Adicionar Saldo", callback_data="add_saldo"),
                #InlineKeyboardButton("🗂️ Histórico", callback_data="history"),   
            ],
            [
                InlineKeyboardButton("⭐️ Avaliar Store", callback_data="avaliar_store"),
                InlineKeyboardButton("💶 Transferir Saldo", callback_data="transfer_saldo"),
            ],
			[
				InlineKeyboardButton("💸 Adicionar Saldo", callback_data="add_saldo"),
			],
            [
				InlineKeyboardButton("🎁 Caixa Misteriosa", callback_data="caixa_misteriosa"),
                InlineKeyboardButton("💎 Meu Perfil", callback_data="user_info"),
                #InlineKeyboardButton("🏦 LARA MP", callback_data="comprar_MP"),
            ],
			[
				InlineKeyboardButton("🔰 Administração", callback_data="admin_action"),
			],
        ]
    )

    start_message = f"""<a href=''</a>&#8204</a><b>🔵 Olá {m.from_user.first_name} seja bem-vindo á Store!</b>

<b>💰 | Recarregue rapidamente pelo</b><code> /pix!</code>
<b>🎫 | Precisa de suporte? Use</b><code> /ticket</code><b> para abrir um chamado!</b>"""

    if isinstance(m, CallbackQuery):
        await m.edit_message_text(start_message, reply_markup=kb)
    else:
        await m.reply_text(start_message, reply_markup=kb, reply_to_message_id=m.id)
    
    save()

# Callback para lidar com a ação do botão de administrador
@Client.on_callback_query(filters.regex("^admin_action$"))
async def admin_action_callback(c: Client, callback_query: CallbackQuery):
    user_id = callback_query.from_user.id
    if user_id in ADMINS:
        await callback_query.answer("✅️ Ação de administrador realizada!")
        # Aqui você pode redirecionar para outro callback_data específico
        another_callback_data = "painel"
        await callback_query.edit_message_reply_markup(
            reply_markup=InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton(
                            text="🔷️📈 Painel de Administração",
                            callback_data=another_callback_data
                        )
                    ]
                ]
            )
        )
    else:
        await callback_query.answer("⭕️ Você não tem permissão para acessar este menu.", show_alert=True)