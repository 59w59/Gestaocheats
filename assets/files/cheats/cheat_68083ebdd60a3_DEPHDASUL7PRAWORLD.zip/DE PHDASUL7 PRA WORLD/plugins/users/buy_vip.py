from pyrogram import Client, filters
from database import cur, save
from config import BOT_LINK_SUPORTE
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, Message
import sqlite3

app = Client("my_bot")

# Conexão com o banco de dados
def get_db_connection():
    conn = sqlite3.connect("main.db")  # Substitua pelo caminho do seu banco de dados
    return conn

# Função para obter o saldo do usuário
def get_user_balance(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cur.execute("SELECT balance FROM users WHERE id = ?", (user_id,))
    result = cur.fetchone()
    save()
    return result[0] if result else 0

# Função para subtrair saldo do usuário
def subtract_user_balance(user_id, amount):
    conn = get_db_connection()
    cursor = conn.cursor()
    cur.execute("UPDATE users SET balance = balance - ? WHERE id = ?", (amount, user_id))
    conn.commit()
    save()

# Função para atualizar o ID do grupo Premium e o valor
def update_premium_info(group_id, price):
    conn = get_db_connection()
    cursor = conn.cursor()
    cur.execute("UPDATE settings SET premium_group_id = ?, premium_price = ?", (group_id, price))
    conn.commit()
    save()

# Função para obter o ID do grupo Premium e o valor
def get_premium_info():
    conn = get_db_connection()
    cursor = conn.cursor()
    cur.execute("SELECT premium_group_id, premium_price FROM settings LIMIT 1")
    result = cursor.fetchone()
    save()
    return result if result else ("123456", 10)  # Valores padrão

# Callback para mostrar os planos disponíveis
@Client.on_callback_query(filters.regex("^show_plans$"))
async def show_plans(client, callback_query):
    group_id, premium_price = get_premium_info()
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(f"✅ Grupo Premium vitalício - R${premium_price},00", callback_data="buy_premium"),
            ],
            [
                InlineKeyboardButton("« Voltar", callback_data="shop"),
            ],
        ]
    )
    await callback_query.message.edit("""<b>✅ CANAL DE MÉTODOS E ESQUEMAS VIP ✅</b>

<i>😍 PROMOÇÃO ACESSO AO MEU CANAL DE MÉTODOS + CANAL DE BINS E CONSULTAS INCLUSO POR APENAS R${premium_price},00.</i>

✅ BY: @{BOT_LINK_SUPORTE}

▶️ MAIOR VENDEDOR DE METODOS
😱 BINS PRIVADAS FEITAS POR MIM
🇧🇷 1610 CLIENTES JA COMPRARAM
✅️ BINS E MÉTODOS ATUALIZADAS TODOS OS DIAS
💰 PREÇO POR TEMPO LIMITADO: R${premium_price},00
➖ ACESSO VITALÍCIO ( PAGA SO 1 VEZ )
🔔 BENEFÍCIOS: PUXADAS VIP CHECKER DE CC, CHECKER DE GG GERADOR DE CONTAS PREMIUM, DONATE DE CC'S.
📺 DONATES DE IPTV E CONTAS E CCS.

<b>📎 METODOS ESTÃO EM:</b>

😀 VIDEOS AULAS
😀 TEXTO
📑 ARQUIVO 
📚 PDF""", reply_markup=kb)

# Callback para processar a compra
@Client.on_callback_query(filters.regex("^buy_premium$"))
async def buy_premium(client, m: CallbackQuery):
    user_id = m.from_user.id
    group_id, premium_price = get_premium_info()

    # Obter saldo do usuário
    saldo = get_user_balance(user_id)

    if saldo >= premium_price:
        # Subtrair saldo
        subtract_user_balance(user_id, premium_price)

        # Adicionar usuário ao grupo Premium
        client.add_chat_members(group_id, user_id)

        return await m.answer("✅💎 Compra efetuada com sucesso! Você foi adicionado ao grupo Premium vitalício.", show_alert=True)
    else:
        return await m.answer("⚠️ Saldo insuficiente para a compra do grupo Premium vitalício.", show_alert=True)
