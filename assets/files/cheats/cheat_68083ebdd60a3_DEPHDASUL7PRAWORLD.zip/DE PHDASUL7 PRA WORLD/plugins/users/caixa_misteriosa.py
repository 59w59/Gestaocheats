from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import random
from config import GRUPO_PUB, BOT_LINK_SUPORTE, ADMIN_CHAT, BOT_LINK
import sqlite3
from pyrogram.types import (
    CallbackQuery,
    Message,
)

app = Client("my_bot")

# Conexão com o banco de dados SQLite
conn = sqlite3.connect("main.db", check_same_thread=False)
cur = conn.cursor()

# Lista de prêmios possíveis
prizes = ["🏆 5 GG", "🔐 5 LOGINS", "❌ SEM SORTE, TENTE OUTRA VEZ"]

# Valor da Caixa Misteriosa
MYSTERY_BOX_COST = 15.00

# ID do administrador
ADMIN_ID = 1454938346

def save():
    conn.commit()

def mystery_box_button():
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("Abrir Caixa Misteriosa - R$15,00", callback_data="open_mystery_box")],
    ])
    return keyboard

async def msg_group_caixa(mention, prize, BOT_LINK_SUPORTE):
    produto = (
        f"🎉<b>Caixa Misteriosa Comprada com sucesso!</b>\n\n"
        f"<b>💠Prêmio: {prize}\n"
        f"<b>🔹Preço: R$15\n"
        f"<b>🥤{mention} obrigado pela a preferencia 💎</b>\n\n"
        f"<a href='https://t.me/{BOT_LINK_SUPORTE}'>SUPORTE</a>"
    )
    return produto
  
@Client.on_callback_query(filters.regex(r"^caixa_misteriosa$"))
async def caixa_misteriosa(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
              InlineKeyboardButton("✅ Abrir Caixa Misteriosa - R$15,00", callback_data="open_mystery_box"),
            ],
            [
              InlineKeyboardButton("⬅️ Voltar", callback_data="start"),
			],
		]
    )

    await m.edit_message_text(
        f"""<a href=''>&#8204</a><b>🎁 CAIXA MISTERIOSA - R$ 15,00</b>
        
<i>🔍 Você está pronto para descobrir o que há dentro?</i>
Por apenas <b>R$ 15,00</b>, você pode abrir nossa <b>Caixa Misteriosa</b> e ter a chance de ganhar prêmios incríveis! Cada caixa vem com uma surpresa exclusiva, que pode variar entre:

<b>🎲 Prêmios Possíveis:</b>

🏆 5 GG
🔐 5 LOGINS
💳 10 GG MIX
❌ SEM SORTE

<i>Cada caixa é uma nova oportunidade de ganhar algo especial. A emoção da surpresa está garantida! Não perca a chance de ser um dos sortudos!</i>

<b>Clique no botão abaixo para abrir sua Caixa Misteriosa agora!</b>""",
        reply_markup=kb,
    )
  
# Callback para abrir a Caixa Misteriosa
@Client.on_callback_query(filters.regex("open_mystery_box"))
async def open_mystery_box(client, m: CallbackQuery):
    user_id = m.from_user.id
    user_name = m.from_user.username
    mention = m.from_user.first_name
  
    # Verificar o saldo do usuário
    user_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()
    if not user_balance or user_balance[0] < MYSTERY_BOX_COST:
        await m.answer("❌ Você não tem saldo suficiente para abrir a Caixa Misteriosa!", show_alert=True)
        return

    # Subtrair o valor da Caixa Misteriosa do saldo do usuário
    cur.execute("UPDATE users SET balance = balance - ? WHERE id = ?", [MYSTERY_BOX_COST, user_id])
    save()

    # Escolher um prêmio aleatório
    prize = random.choice(prizes)

    if prize == "❌ SEM SORTE, TENTE OUTRA VEZ":
        await m.message.reply("❌ Infelizmente, você não teve sorte desta vez. Mas não desista! Tente outra vez.")
        notification_message = f"⚠️ O usuário @{user_name} ({user_id}) abriu a caixa misteriosa, mas não teve sorte desta vez."
    else:
        await m.message.reply(f"""🎉🎁 Parabéns! Você ganhou: {prize}!
        
<i>⚠️ Entre em contato com um administrador e resgate seu prêmio.</i>""")
        notification_message = f"📢 O usuário @{user_name} ({user_id}) abriu a caixa misteriosa e ganhou: {prize}."

    pub = await msg_group_caixa(mention, prize, BOT_LINK_SUPORTE)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🎁 Comprar Caixa Misteriosa", url=f"https://t.me/{BOT_LINK}"),
            ],
        ]
    )

    await client.send_photo(GRUPO_PUB, photo='https://ibb.co/hd1w3BF', caption=pub, reply_markup=kb)

    await m.answer("✅️🎁 Caixa Misteriosa Aberta!")

    # Enviar notificação ao administrador
    await client.send_message(ADMIN_CHAT, notification_message)

