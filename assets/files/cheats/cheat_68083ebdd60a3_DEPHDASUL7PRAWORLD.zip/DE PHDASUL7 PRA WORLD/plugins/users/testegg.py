import asyncio
import random
from pyrogram import Client, filters
from .start import start  # Importa a função start do módulo start.py
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, InputMediaPhoto, CallbackQuery
from config import ADMIN_CHAT, GRUPO_PUB, BOT_LINK, BOT_LINK_SUPORTE
from database import cur, save

ITEMS_PER_PAGE = 10

async def get_price(type, code):
    # Função fictícia para obter o preço. Substitua pelo código real.
    return 5

async def msg_group_publico_cards(mention, level, type_buy, price, bin_card, BOT_LINK_SUPORTE):
    produto = (
        f"🎉<b>GG Comprada com sucesso!</b>\n\n"
        f"<b>💠Bin: {bin_card}xxxxxxxxxx</b>\n"
        f"<b>🔹Preço: R$ {price}</b>\n"
        f"<b>🥤{mention} obrigado pela a preferencia 💎</b>\n\n"
        f"<a href='https://t.me/{BOT_LINK_SUPORTE}'>SUPORTE</a>"
    )
    return produto


async def msg_buy_user(user_id, card_info, vendor, country, bank, level_cc, price, balance, cpf_name=None):
    number, month, year, cvv = card_info.split("|")

    message = f"""
    <b>✅ Compra realizada com sucesso!</b>

<b>Testar GG no site: https://www.primetek.com.br/\nRetornos: VISA N7/51 , ELO 63 , MASTER 83/12 , AMEX FA/A6 LIVE!✅🥷</b>

<b>💳 Número do cartão:</b> <code>{number}</code>
<b>📆 Validade:</b> <code>{month}/{year}</code>
<b>🔐 CVV:</b> <code>{cvv}</code>
    
<b>💸 Valor:</b> <code>R${price}</code>

<b>⏰ TEMPO PRA PROVAR QUE GG ESTÁ DIE:</b> <code>10min</code>
    """
    
    if cpf_name:
        cpf, name = cpf_name
        message += f"CPF: {cpf}\nNome: {name}\n"
    
    return message

@Client.on_callback_query(filters.regex(r"^ggs$"))
async def codeee(client: Client, m: CallbackQuery):
    await show_page(client, m, 1)

async def show_page(client: Client, m: CallbackQuery, page: int):
    list_levels_cards = cur.execute("SELECT level FROM ggs GROUP BY level").fetchall()
    list_bins_cards = cur.execute("SELECT bin FROM ggs GROUP BY bin").fetchall()
    levels_list = [x[0] for x in list_levels_cards]
    bin_list = [x[0] for x in list_bins_cards]

    if not levels_list:
        return await m.answer(
            "⚠️ Não há GGs disponíveis no momento, tente novamente mais tarde.",
            show_alert=True
        )

    start_idx = (page - 1) * ITEMS_PER_PAGE
    end_idx = start_idx + ITEMS_PER_PAGE
    current_bins = bin_list[start_idx:end_idx]

    buttons = []
    levels = []
    row = []  # Cria uma lista para armazenar os botões em uma linha
    for bin in current_bins:
        row.append(InlineKeyboardButton(f"💳 {bin}", callback_data=f"bin_info:{bin}:{page}"))
        if len(row) == 2:  # Define quantos botões por linha (neste exemplo, 3 por linha)
            buttons.append(row)  # Adiciona a linha completa ao teclado
            row = []  # Reseta a linha para a próxima

    if row:  # Adiciona qualquer botão restante em uma nova linha
        buttons.append(row)

    navigation_buttons = []
    if page > 1:
        navigation_buttons.append(InlineKeyboardButton("◀️", callback_data=f"navigate:prev:{page-1}"))
    if end_idx < len(bin_list):
        navigation_buttons.append(InlineKeyboardButton("▶️", callback_data=f"navigate:next:{page+1}"))
    buttons.append(navigation_buttons)
    buttons.append([InlineKeyboardButton("🔻 Voltar", callback_data="shop")])

    current_message_text = m.message.text  # Corrigido aqui, removido os parênteses

    await m.message.edit_text(
        "📦 Escolha uma BIN para ver detalhes:",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


@Client.on_callback_query(filters.regex(r"^bin_info:(.*):(.*)$"))
async def bin_info(client: Client, m: CallbackQuery):
    bin_code = m.data.split(":")[1]
    page = int(m.data.split(":")[2])
    price = await get_price("bin", bin_code)
  
    user_id = m.from_user.id
    user_info = cur.execute("SELECT id, balance FROM users WHERE id=?", [user_id]).fetchone()
    balance = user_info[1] if user_info else 0

    text = f"""
    <b>💳 Detalhes da BIN:</b> <code>{bin_code}</code>
<b>💸 Valor:</b> <code>R${price}</code>
<b>💰 Seu Saldo:</b> <code>R${balance}</code>
    """

    buttons = [
        [InlineKeyboardButton("🛒 Comprar", callback_data=f"buy_bin:{bin_code}:{price}")],
        #[InlineKeyboardButton("◀️", callback_data=f"navigate:prev:{page}")],
        #[InlineKeyboardButton("▶️", callback_data=f"navigate:next:{page}")],
        [InlineKeyboardButton("🔻 Voltar", callback_data="ggs")],
    ]

    await m.message.edit_text(
        text,
        reply_markup=InlineKeyboardMarkup(buttons)
    )

@Client.on_callback_query(filters.regex(r"^buy_bin:(.*):(.*)$"))
async def buy_bin(client: Client, m: CallbackQuery):
    bin_code = m.data.split(":")[1]
    price = int(m.data.split(":")[2])

    user_id = m.from_user.id
    user_info = cur.execute("SELECT id, balance FROM users WHERE id=?", [user_id]).fetchone()
    balance = user_info[1] if user_info else 0

    if balance < price:
        await m.answer(
            "⚠️ Saldo insuficiente para a compra.",
            show_alert=True
        )
        return

    # Proceder com a compra
    ccs_list = cur.execute(
        "SELECT number, month, year, cvv, level, added_date, vendor, bank, country, cpf, name FROM ggs WHERE bin = ? AND pending = ? ORDER BY RANDOM() LIMIT 1",
        [bin_code, False]
    ).fetchall()

    if not ccs_list:
        await m.answer(
            "⚠️ Não foi possível encontrar o cartão, tente novamente.",
            show_alert=True
        )
        return

    tp = ccs_list[0]
    number, month, year, cvv, level_cc, added_date, vendor, bank, country, cpf, name = tp

    card_info = f"{number}|{month}|{year}|{cvv}"
    base = await msg_buy_user(
        user_id,
        card_info,
        vendor,
        country,
        bank,
        level_cc,
        price,
        balance,
        (cpf, name) if cpf is not None else None,
    )

    cur.execute("UPDATE ggs SET pending = 1 WHERE number = ?", [number])
    cur.execute(
        "UPDATE users SET balance = ? WHERE id = ?",
        [balance - price, user_id]
    )
    cur.execute("DELETE FROM ggs WHERE number = ?", [number])
    save()

    await m.message.edit_text(base)
    number_str = str(number)
    first_four_digits = number_str[:4]
    mention = m.from_user.first_name

    pub = await msg_group_publico_cards(mention, level_cc, bank, price, first_four_digits, BOT_LINK_SUPORTE)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💳 Comprar Ggs Unitária", url=f"https://t.me/{BOT_LINK}"),
            ],
        ]
    )

    await client.send_message(GRUPO_PUB, text=pub, reply_markup=kb)

@Client.on_callback_query(filters.regex(r"^navigate:prev:(\d+)$"))
async def prev_page(client: Client, m: CallbackQuery):
    page = int(m.data.split(":")[2])
    await show_page(client, m, page)

@Client.on_callback_query(filters.regex(r"^navigate:next:(\d+)$"))
async def next_page(client: Client, m: CallbackQuery):
    page = int(m.data.split(":")[2])
    await show_page(client, m, page)

@Client.on_callback_query(filters.regex(r"^back_to_menu$"))
async def back_to_menu(client: Client, m: CallbackQuery):
    await codeee(client, m)
