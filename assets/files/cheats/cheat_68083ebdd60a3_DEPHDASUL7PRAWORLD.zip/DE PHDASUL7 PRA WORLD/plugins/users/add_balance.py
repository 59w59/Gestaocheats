import math
from typing import Union
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from config import ADMIN_CHAT, GRUPO_PUB, BOT_LINK, BOT_LINK_SUPORTE
from database import cur, save
from utils import create_mention, get_lara_info, get_support_user, insert_sold_balance, insert_sold_balancep
from typing import Union

@Client.on_callback_query(filters.regex(r"^add_saldo$"))
async def add_saldo(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("💰 Pix Automático", callback_data="add_saldo_auto"),
                InlineKeyboardButton("💵 Recarga manual", callback_data="add_saldo_manual"),
            ],
            [InlineKeyboardButton("🔙 Voltar", callback_data="start")],
        ]
    )

    await m.edit_message_text(
        """<b>💵 Adicionar saldo</b>
<i>- Aqui abaixo você poderá adicionar saldo de duas formas, ou <b>pix automático</b> ou <b>pix manual</b>.</i>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^add_saldo_manual$"))
async def add_saldo_manual(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton("🔙 Voltar", callback_data="add_saldo")],
        ]
    )

    pix_name, pix_key = get_lara_info()
    support_user = get_support_user()
    valor_min = 20
    details = (
        f"\n\n<i>⚠️ Não envie um valor</i> <b>MENOR</b> <i>que R$ {valor_min}, pois se você enviar perderá seu dinheiro.</i>"
        if valor_min
        else ""
    )

    await m.edit_message_text(
        f"""<b>✨ Adicione saldo Manualmente!</b>

<b>⚠️ Atenção:
Não envie uma transferência menor que R$ 5 usando o pagamento manual, pois não será aceito e a forma de reembolso não será válida</b>

━━━━━━━━━━━━━━━━━━━━━━

<b>• 💠 Chave Pix:</b> <code>{pix_key}</code>
• 🧑‍💻 <b>Nome:</b> <code>{pix_name}</code>

<b>✅ Após enviar o comprovante nossa equipe verificará, e se o pagamento for aprovado, enviaremos um gift de resgate em seu privado.</b>

━━━━━━━━━━━━━━━━━━━━━━

<b>🧾 Envie o Comprovante para um dos admins abaixo e aguarde a confirmação:</b>

👨🏻‍💻 <b>Suporte: https://t.me/{BOT_LINK_SUPORTE}</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^btc$"))
async def btc(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton("Voltar", callback_data="add_saldo")],
        ]
    )

    pix_name, pix_key = get_lara_info()
    support_user = BOT_LINK_SUPORTE
    valor_min = 20
    details = (
        f"\n\n<i>⚠️ Não envie um valor</i> <b>MENOR</b> <i>que R$ {valor_min}, pois se você enviar perderá seu dinheiro.</i>"
        if valor_min
        else ""
    )

    await m.edit_message_text(
        f"""<b>💰Bitcoin Manual</b>\n\n
Para adicionar saldo via Bitcoin, envie a quantia desejada para nosso endereço Bitcoin, segue o endereço:\n\n

<code>Endereço aqui</code>\n\n

Após enviar, chame {support_user} e mande o link da transação.
Será adicionado exatamente o valor que chegar à carteira.
{details}""",
        reply_markup=kb,
    )        

@Client.on_message(filters.regex(r"/resgatar (?P<gift>\w+)$"))
@Client.on_callback_query(filters.regex(r"^resgatar (?P<gift>\w+)$"))
async def resgatar_gift(c: Client, m: Union[CallbackQuery, Message]):
    user_id = m.from_user.id
    gift = m.matches[0]["gift"]
    send = m.edit_message_text if isinstance(m, CallbackQuery) else m.reply_text

    try:
        value = cur.execute("SELECT value from gifts WHERE token = ?", [gift]).fetchone()[0]
    except:
        return await send("<b>⚠️ Gift card não existente ou já resgatado.</b>")

    cur.execute("DELETE FROM gifts WHERE token = ?", [gift])
    cur.execute("UPDATE users SET balance = balance + ? WHERE id = ?", [value, user_id]).fetchone()

    new_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]

    mention = create_mention(m.from_user)
    insert_sold_balance(value, user_id, "manual")
    base = f"""<b>💸 {mention} resgatou um gift card de <b>R${value}
- Novo saldo: R${new_balance}</b>
<b>- Gift card: <code>{gift}</code> </b>"""

    await c.send_message(ADMIN_CHAT, base)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🤖 Registre-se", url=f"https://t.me/{BOT_LINK}")],
        ]
    )
    mention = m.from_user.first_name
    base = f"""<b>🎁 {mention} resgatou um gift card de <b>R${value}</b>
<b>- Novo saldo: R${new_balance}</b>
- Gift card: <code>{gift}</code> </b> <a href='https://t.me/{BOT_LINK_SUPORTE}'>Suporte</a>"""
    await c.send_message(GRUPO_PUB, base, reply_markup=kb)

    if isinstance(m, CallbackQuery):
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton("🛒 Voltar ao bot", url=f"https://t.me/{c.me.username}?start=start")],
            ]
        )
        await send(f"<b>🎉 {m.from_user.first_name} resgatou R$ {value} no bot via gift card.</b>", reply_markup=kb)
    else:
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton("Menu", callback_data="start")],
            ]
        )
        await send(f"""<b>🟢 R${value} Adicionado</b>

💵 <b>Novo saldo: R${new_balance}</b> """, reply_markup=kb)

    save()

@Client.on_message(filters.regex(r"/gif (?P<giftp>\w+)$"))
@Client.on_callback_query(filters.regex(r"^gif (?P<giftp>\w+)$"))
async def resgatar_giftp(c: Client, m: Union[CallbackQuery, Message]):
    user_id = m.from_user.id
    giftp = m.matches[0]["giftp"]
    send = m.edit_message_text if isinstance(m, CallbackQuery) else m.reply_text

    try:
        pont = cur.execute("SELECT pont from pontos WHERE tokenp = ?", [giftp]).fetchone()[0]
    except:
        return await send("<b>⚠️ Gift card não existente ou já resgatado.</b>")

    cur.execute("DELETE FROM pontos WHERE tokenp = ?", [giftp])
    cur.execute("UPDATE users SET balance_diamonds = balance_diamonds + ? WHERE id = ?", [pont, user_id]).fetchone()

    new_balance = cur.execute("SELECT balance_diamonds FROM users WHERE id = ?", [user_id]).fetchone()[0]

    mention = create_mention(m.from_user)
    insert_sold_balancep(pont, user_id, "manual")
    base = f"""<b>💸 {mention} resgatou um gift De Pontos de <b>R${pont}</b>
- Novo saldo: <b>R${new_balance}</b>
- Gift Pontos: <code>{giftp}</code>"""

    await c.send_message(ADMIN_CHAT, base)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🤖 Registre-se", url=f"https://t.me/{BOT_LINK}")],
        ]
    )
    mention = m.from_user.first_name
    base = f"""<b>🎁 {mention} resgatou um gift de pontos no valor de: R${pont}</b>
<b>Obrigado {mention} pela preferência
- Gift Pontos: <code>{giftp[0:6]}</code>\n<a href='https://t.me/{BOT_LINK_SUPORTE}'>Suporte</a> </b>"""
    await c.send_message(GRUPO_PUB, base, reply_markup=kb)

    if isinstance(m, CallbackQuery):
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton("🛒 Voltar ao bot", url=f"https://t.me/{c.me.username}?start=start")],
            ]
        )
        await send(f"<b>🎉 {m.from_user.first_name} resgatou R$ {pont} no bot via gift card.</b>", reply_markup=kb)
    else:
        await send(f"<b>🎉 Agora sim 👏 foi adicionado R$ {pont} em sua conta no bot.</b>")

    save()