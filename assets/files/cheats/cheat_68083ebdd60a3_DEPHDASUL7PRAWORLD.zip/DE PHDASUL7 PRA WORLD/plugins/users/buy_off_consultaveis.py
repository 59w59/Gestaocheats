import asyncio
import time
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    Message,
    InlineQueryResultArticle,
    InputTextMessageContent,
)

from config import ADMIN_CHAT,GRUPO_PUB
from config import LOG_CHAT
from config import BOT_LINK_SUPORTE
from database import cur, save
from utils import (
    create_mention,
    get_price,
    insert_sold_balance,
    get_info_wallet,
    msg_buy_off_user,
    msg_buy_user,
    msg_group_adm,
    msg_group_publico_consul,
)

# Pesquisa de CCs via inline.
@Client.on_inline_query(filters.regex(r"^consul_(?P<type>\w+) (?P<value>.+)"))
async def search_cc_consul(c: Client, m: InlineQuery):
    """
    Pesquisa uma CC via inline por tipo e retorna os resultados via inline.

    O parâmetro `type` será o tipo de valor para pesquisar, ex.:
        bin (Por bin), bank (Por banco), vendor (Por bandeira), etc.
    O parâmetro `value` será o valor para pesquisa, ex.:
        550209 (Bin), Nubank (Banco), Mastercard (Bandeira), etc.
    """

    typ = m.matches[0]["type"]
    qry = m.matches[0]["value"]
    qry = qry[0:6]

    # Não aceitar outros valores para prevenir SQL Injection.
    if typ not in ("buy", "banco", "bandeira"):
        return

    if typ != "bin":
        qry = f"%{qry}%"

    if typ == "buy":
        typ2 = "nomebanco"
    elif typ == "bandeira":
        typ2 = "vendor"
    else:
        typ2 = typ

    rt = cur.execute(
        f"SELECT cc, mes, ano, {typ2}, limite, nome, anjo, token, bincc, preco, nomebanco FROM consul WHERE {typ2} LIKE ? AND pending = 0 ORDER BY RANDOM() LIMIT 50",
        [qry.upper()],
    ).fetchall()

    results = []

    wallet_info = get_info_wallet(m.from_user.id)

    for number, month, year, value, limite, nome, anjo, token, bincc, preco, nomebanco in rt:

        price = preco

        base = f"""LIMITE: {limite}
BANCO: {nomebanco}
TIPO: {bincc}"""

        base_ml = f"""<b>Cartão:</b> <i>{number[0:6]}**********</i>
        
<b>VALIDADE:</b> <i>**/****</i>
<b>CVV:</b> <i>***</i>
<b>NOME:</b> {nome}</b>
<b>ANJO:</b> {anjo}</b>
<b>TOKEN:</b> {token}</b>
<b>TIPO CONSUL:</b> {bincc}</b>
<b>BANCO:</b> {nomebanco}</b>

<b>Valor:</b> <i>R$ {price}</i>"""

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="✅ Comprar",
                        callback_data=f"comprar_consul cc '{number}'",
                    )
                ]
            ]
        )
        thumb = "https://cdn-icons-png.flaticon.com/512/4553/4553547.png"
        results.append(
            InlineQueryResultArticle(
                title=f". {typ} {value} - R$ {price}",
                description=base,
                thumb_url=thumb,
                input_message_content=InputTextMessageContent(
                    base_ml 
                ),
                reply_markup=kb,
            )
        )

    await m.answer(results, cache_time=5, is_personal=True)




#compra da consul
@Client.on_callback_query(
    filters.regex(r"^comprar_consul (?P<type>[a-z]+) '(?P<level_cc>.+)' ?(?P<other_params>.+)?")  # fmt: skip
)
#@lock_user_buy
async def buy_off_consul(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    balance: int = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]  # fmt: skip

    type_cc = "bin"
    level_cc = m.matches[0]["level_cc"]

    

    search_for = "level" if type_cc == "unit" else "cc"

    selected_cc = cur.execute(
        f"SELECT limite, preco, anjo, token, cc, bincc, senha, mes, ano, cvv, cpf, telefone, nome, added_date, nomebanco FROM consul WHERE {search_for} = ? AND pending = ? ORDER BY RANDOM() LIMIT 20",
        [level_cc, False],
    ).fetchone()
    
    
    

    if not selected_cc:
        return await m.answer("⚠️ Sem consul disponiveis para este nivel.", show_alert=True)

    (
        limite,
        preco,
        anjo,
        token,
        cc,
        bincc,
        senha,
        mes,
        ano,
        cvv,
        cpf,
        telefone,
        nome,
        added_date,
        nomebanco,     
    ) = selected_cc
    
    price = int(preco)

    if balance < price:
        return await m.answer(
            f"⚠️ Você Não Possui Saldo suficiente Para Esse Item Por favor, Faça Uma Recarga.",
            show_alert=True,
        )
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("📲 Enviar Print", url="https://t.me/{BOT_LINK_SUPORTE}"),
            ],
        ]
    )
    
    
    cur.execute(
        "DELETE FROM consul WHERE cc = ?",
        [selected_cc[4]],
    )

  
    
    
    await m.edit_message_text(
            "<b>🔄 Por favor aguarde, estou realizando a sua compra...</b>"
        )
    time.sleep(2)
    
    
    insert_sold_balance(price, user_id, "consul")         
    now = 2
    list_itens = "limite, preco, anjo, token, cc, bincc, senha, mes, ano, cvv, cpf, telefone, nome, added_date, nomebanco, bought_date, owner"
    atest = cur.execute(
        f"INSERT INTO consul_solds({list_itens}) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [limite, preco, anjo, token, cc, bincc, senha, mes, ano, cvv, cpf, telefone, nome, added_date, nomebanco, now, user_id],
    )
    print(atest)
    save()
    live_or_die = True
    if live_or_die == True:  # caso venha cc live
                diamonds = 0
                new_balance = round(balance - price, 2)

                cur.execute(
                    "UPDATE users SET balance = round(balance - ?, 2), balance_diamonds = round(balance_diamonds + ?, 2) WHERE id = ?",
                    [price, diamonds, user_id],
                )
    level_cc = bincc
    card = cc
    type_cc = "Consultavel"
    price = preco
    status = "Compra efetuada"
    vendor = f"{mes}|{ano}|{cvv} - {nome} - {senha} - Consul: {nomebanco}"
    
              
    mention = create_mention(m.from_user)
    adm_msg = msg_group_adm(
                    mention,
                    card,
                    level_cc,
                    type_cc,
                    price,
                    status,
                    new_balance,
                    vendor,
                )
                
    mention = m.from_user.first_name
                
    pub_msg = msg_group_publico_consul(
                    mention,
                    card,
                    level_cc,
                    type_cc,
                    price,
                    status,
                    new_balance,
                    nomebanco,
                )
    await c.send_message(ADMIN_CHAT, adm_msg)
                
    await c.send_message(GRUPO_PUB, pub_msg)
    
    base = f"""<b>💳 Consultavel Comprada Com Sucesso!</b>

<b>💸 Preço: {preco}</b>
<b>💸 Seu saldo atual após a compra: {balance}</b>

<b>💳 DADOS DA CONSUL:</b>
<b>LIMITE: R${limite}</b>
<b>CC: <code>{cc}</code></b>
<b>CVV: <code>{cvv}</code></b>
<b>VALIDADE: <code>{mes}/{ano}</code></b>
<b>SENHA: <code>{senha}</code></b>

<b>🏦 BANCO DA CONSUL:</b>
<b>BANCO: {nomebanco}</b>
<b>TIPO: {bincc}</b>

<b>🪪 DADOS DO DONO:</b>
<b>NOME: <code>{nome}</code></b>
<b>CPF: <code>{cpf}</code></b>
<b>TELEFONE: <code>{telefone}</code></b>

<b>ANJO: {anjo}</b>
<b>TOKEN: {token}</b>

<b>Suporte @{BOT_LINK_SUPORTE}</b>"""

    
    await m.edit_message_text(base, reply_markup=kb,)