import json
import time
import asyncio

from config import BOT_LINK
from asyncio import sleep
from pyrogram import Client, filters
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

@Client.on_message(filters.command(["id"], ["/", "."]))
async def chaid(_, m: Message):
    # Crie um botão inline com um link
    inline_button = InlineKeyboardButton("Ir para a Store", url="t.me/{BOT_LINK}")

    # Crie um teclado inline com o botão
    reply_markup = InlineKeyboardMarkup([[inline_button]])

    await m.reply(f"""    
<b>Chat Id</b> : <b><code>{m.chat.id}</code></b>
    """, reply_markup=reply_markup)