from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet, dobrosaldo

def obter_resultados(resultados):
    saida = ""
    for categoria, valores in list(resultados.items())[:3]:
        saida += f"\n\n💳 | ↓{len(valores)}    {categoria}\n"
        for valor in valores:
            saida += f"    {valor}"
    return saida


@Client.on_message(filters.command(["consul", "consul"]))
@Client.on_callback_query(filters.regex("^consul$"))
async def start(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id

    rt = cur.execute(
        "SELECT id, balance, balance_diamonds, refer FROM users WHERE id=?", [user_id]
    ).fetchone()

    if isinstance(m, Message):
        """refer = (
            int(m.command[1])
            if (len(m.command) == 2)
            and (m.command[1]).isdigit()
            and int(m.command[1]) != user_id
            else None
        )

        if rt[3] is None:
            if refer is not None:
                mention = create_mention(m.from_user, with_id=False)

                cur.execute("UPDATE users SET refer = ? WHERE id = ?", [refer, user_id])
                try:
                    await c.send_message(
                        refer,
                        text=f"<b>O usuário {mention} se tornou seu referenciado.</b>",
                    )
                except BadRequest:
                    pass"""

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
           [
             InlineKeyboardButton("🔎 Comprar",switch_inline_query_current_chat="consul_buy ITAU",),
             InlineKeyboardButton("🔸 Atualizar",callback_data="consul"),
	    	   ],
	    	   [
              InlineKeyboardButton("« Voltar",callback_data="shop"),
           ], 
	    ]
    )
    table_name = "consul"
    ccs = cur.execute(
        f"SELECT nomebanco, count() FROM {table_name} GROUP BY nomebanco ORDER BY count() DESC"
    ).fetchall()
    
    counts = cur.execute(
        f"SELECT COUNT(*) FROM consul"
    ).fetchone()

    stock = (
        "\n".join([f"<b>{it[0]}</b>: {it[1]}" for it in ccs])
        or "<b>⚠️ Sem Consultaveis Disponivel</b>"
    )
    total = f"<b>Total</b>: {sum([int(x[1]) for x in ccs])}" if ccs else""
    
    
    resultados = {}
    first_three = list(resultados.items())[:3]

    for it in ccs:
    	rt = cur.execute(
    	f"SELECT limite, preco, anjo, token, cc, bincc, senha,mes, ano, cvv, cpf, telefone, nome, added_date,nomebanco FROM consul WHERE nomebanco = ? ORDER BY RANDOM() LIMIT 20",
    	[it[0]],).fetchall()
    	print(rt)
    	print(rt[0])
    	#message = f"""R$ {rt[1]}  {rt[4][0:6]}**********"""
#    	#results.append(rt)
    	for tp in rt:
            (
                limite,
                preco,
                anjo,
                token,
                cc,
                bincc,
                senha,
                mes,
                ano,
                cvv,
                cpf,
                telefone,
                nome,
                added_date,
                nomebanco,
            ) = tp
            message = f"""R${preco} - <code>{cc[0:12]}</code> - {nome} - R${limite}"""
            #cons.append(message)
            #linha = f"kkkkkkks {k}"
            chave = f"{nomebanco}"
            if chave not in resultados:
            	resultados[chave] = []
            resultados[chave].append(message)
            
            

            

#    resultados = {
#   'categoria1': [('item1', 'categoria1', 'descricao1'),
#   ('item3', 'categoria1', 'descricao3')],
#   'categoria2': [('item2', 'categoria2', 'descricao2'),
#   ('item4', 'categoria2', 'descricao4')]}
    
    

    
    mention = create_mention(m.from_user, with_id=False)
    start_message = f"""<a href=''>&#8204</a>{mention} Seja Bem Vindo ao Menu de Consultalveis!</b>

<b>✅️ ESCOLHA SUA CONSULTAVEL ABAIXO:</b>

<b>Preço   -   Consultavel    -   Nome   -   Limite</b>

<b>{obter_resultados(resultados)}</b>

<b>💳 Bancos Disponiveis:</b>

{stock}

<i>🛒 Como realizar a compra? 🛍️</i>

<b>1. Confira acima os limites disponíveis e bancos.</b>
<b>2. Clique no botão COMPRAR.</b>
<b>3. Selecione a opção desejada e clique sobre ela!</b>
<b>4. Verifique se seu saldo é equivalente ao preço.</b>
<b>5. Realize sua compra! 💳</b>"""

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text
    save()
    await send(start_message, reply_markup=kb)