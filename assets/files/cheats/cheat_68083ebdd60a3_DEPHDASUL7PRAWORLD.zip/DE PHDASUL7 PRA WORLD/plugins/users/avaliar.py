from pyrogram import Client, filters
from pyrogram.types import Message
from database import cur, save
import sqlite3
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

@Client.on_callback_query(filters.regex(r"^avaliar_store$"))
async def avaliar_store(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Voltar", callback_data="start"),
			],
		]
    )

    await m.edit_message_text(
        f"""<a href=''>&#8204</a><b>⭐️ | SISTEMA DE AVALIAÇÃO</b>

🏷 <i>DÊ UMA NOTA DE 0 a 10 A NOSSA LOJA E GANHE 1$ DE SALDO!!!</i>

✍️ <i>DIGITE /avaliar (DE 1 a 10) E PRONTO!!!</i>

⚠️ <i>EXEMPLO:</i> <code>/avaliar 7</code>""",
        reply_markup=kb,
	)

@Client.on_message(filters.command("avaliar") & filters.private)
async def avaliar_bot(client, message):
    try:
        # Verifica se o comando foi digitado corretamente
        if len(message.command) != 2:
            await message.reply("<i>⚠️ Use o comando corretamente: /avaliar nota</i>")
            return

        # Extrai a nota da avaliação
        nota = int(message.command[1])
        if nota < 1 or nota > 10:
            await message.reply("<i>⚠️ A nota deve estar entre 1 e 10.</i>")
            return

        user_id = message.from_user.id

        # Verifica se o usuário já avaliou
        conn = sqlite3.connect('main.db')
        cur.execute('SELECT has_evaluated FROM users WHERE id = ?', (user_id,))
        save()

        if result and result[0]:
            await message.reply("<i>❌ Você já avaliou o bot uma vez e não pode avaliar novamente.</i>")
            save()
            return
        
        # Atualiza a avaliação e o saldo do usuário
        cur.execute('UPDATE users SET has_evaluated = 1, balance = balance + 1 WHERE id = ?', (user_id,))
        save()

        await message.reply(f"<i>✅️😃 Obrigado pela sua avaliação de {nota} estrelas! Você recebeu R$1 de saldo na Store.</i>")
    except Exception as e:
        await message.reply(f"<b>Ocorreu um erro ao processar sua avaliação: {str(e)}</b>")