from pyrogram import Client, filters
from pyrogram.types import Message, User
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from database import cur, save, db
from utils import get_info_wallet

import datetime
from typing import Union
import asyncio

	
@Client.on_callback_query(filters.regex(r"^delconta$"))
async def delconta(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    "✔️ Sim", callback_data="EXCLUIR"
                ),
            ],
            [InlineKeyboardButton("◀️ Menu", callback_data="user_info")],
        ]
	)

    await m.edit_message_text(
        f"""<b>⚠️ Tem certeza que deseja cancelar a conta? Todas as suas compras, recargas, indicados relacionados e saldo serão excluidos! Caso confirme, não será possível voltar atrás.</b>""",
        reply_markup=kb,
    )
@Client.on_message(filters.command("baixar_infos"))
def download_info(client: Client, message: Message):
    user = message.from_user
    info = f"👤 User: {user.first_name}\n🆔 ID: {user.id}\n👮‍♀️ Admin: Não\n⛑ Suporte: Não\n🚫 Banido: Não\n📣 Canal: https://t.me/PHSantosREFF"
    
    with open("info.txt", "w") as file:
        file.write(info)
    
    message.reply_document("info.txt")
    
    os.remove("info.txt")

@Client.on_callback_query(filters.regex(r"^EXCLUIR$"))
async def excluir_conta(c: Client, m: CallbackQuery):

    # Atualiza os dados da conta do usuário para os valores padrão
    cur.execute(
        "UPDATE users SET balance = 0,  balance_diamonds = 0, agreed_tos = 0, last_bought = NULL, is_action_pending = 0, cpf = NULL, name = NULL, email = NULL WHERE id = ?",
        [m.from_user.id],
    )
    db.commit()

    await m.answer("⚠️ Sua Conta Foi Encerrada!")

    # Exibe uma mensagem para o usuário indicando o encerramento da conta
    await m.edit_message_text(f"""<i>‌🗑 | Excluida!</i>
<i>🚮 • Usuario : {m.from_user.first_name}
🆔 • Id : {m.from_user.id} 
☎️ • Suporte : @{BOT_LINK_SUPORTE}</i>""")

@Client.on_callback_query(filters.regex(r"^user_info$"))
async def user_info(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]
    total_gifts = cur.execute("SELECT COUNT(*) FROM gifts WHERE token IN (SELECT token FROM gifts WHERE value = ?)", [user_id]).fetchone()[0]
    total_cards = cur.execute("SELECT COUNT(*) FROM cards_sold WHERE owner = ?", [user_id]).fetchone()[0]
    total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [user_id]).fetchone()[0]

    user_info = cur.execute("SELECT id, balance FROM users WHERE id=?", [user_id]).fetchone()
    balance = user_info[1] if user_info else 0
    hora_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))
    hora_atual_str = hora_atual.strftime('%H:%M:%S')
    data_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))
    data_atual_str = data_atual.strftime('%d/%m/%Y')
    
    # Consultas para contar as compras em cada aba
    cur.execute("SELECT COUNT(*) FROM logins_sold WHERE owner = ?", (user_id,))
    logins_comprados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM vales_sold WHERE owner = ?", (user_id,))
    vales_comprados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM cards_sold_full WHERE owner = ?", (user_id,))
    cc_full_comprados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM cards_sold WHERE owner = ?", (user_id,))
    cc_auxiliar_comprados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM consulta_solds WHERE owner = ?", (user_id,))
    consultada_comprados = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM consul_solds WHERE owner = ?", (user_id,))
    consultavel_comprados = cur.fetchone()[0]
    save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="📂 Baixar Historico", callback_data="download_info"),
                InlineKeyboardButton(text="💳 Histórico CC's", callback_data="show_cards"),
            ],
            [
                InlineKeyboardButton("🔔 Notificação", callback_data="b_status"),
            ],
            [
                InlineKeyboardButton("⚜️ Trocar pontos", callback_data="swap"),
            ],
            [
            InlineKeyboardButton(text="💻 Desenvolvedor", callback_data="dv"),
            ],
            [
		    #InlineKeyboardButton(text="🗑 Excluir Conta", callback_data="delconta"),
            ],
            [InlineKeyboardButton(text="« Menu Principal", callback_data="start")],
        ]
    )

    link = f"https://t.me/{c.me.username}?start={user_id}"
    await m.edit_message_text(
        f"""<b>✨️ Suas Informações</b>

<b>📛 Nome:</b> <i>{m.from_user.first_name}</i>
<b>🚫 Banido:</b> <i>Não</i>
<b>👮‍♂️ Admin:</b> <i>Não</i>
<b>🗓 Data:</b> <i>{data_atual_str} {hora_atual_str}</i>

<i>-💰 Carteira:</i>
<b>🆔 ID da carteira:</b> <code>{user_id}</code>
<b>💸 Saldo:</b> <code>R${balance}</code>

<i>-🏆 Indicação:</i>
<b>Digite /indicar e obtenha seu link de afiliado!</b>

<i>-🛒 Compras:</i>
<b>💳 Cartões comprados:</b> <code>{cc_full_comprados + cc_auxiliar_comprados}</code>
<b>💳 Consultável compradas:</b> <code>{consultavel_comprados}</code>
<b>💳 Consultada compradas:</b> <code>{consultada_comprados}</code>
<b>🎟️ Logins comprados:</b> <code>{logins_comprados}</code>
<b>🎫 Vales comprados:</b> <code>{vales_comprados}</code>

<i>Para ver seu histórico completo de logins, cartões comprados, GG's comprados, clique no botão baixar histórico logo abaixo!</i>""",
        reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex(r"^gift$"))
async def gift(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            
            
             [
                 InlineKeyboardButton("Voltar", callback_data="start"),
             ],

        ]
    )
    link = f""
    await m.edit_message_text(
        f"""<b>⬇️ Baixar Histórico </b>
<i>Comando : <b>/baixar_infos</b> </i>""",
		reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex(r"^dv$"))
async def desenvolvedor(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⚜️ Alugue Seu Bot", url="https://t.me/PHDASUL7"),
                InlineKeyboardButton("💬 Canal", url="https://t.me/phdasul7metedos"),
            ],
            [
                InlineKeyboardButton("« Voltar", callback_data="user_info"),
            ],
        ]
    )

    await m.edit_message_text(
        f"""⚙ Desenvolvimento do bot.

<i>Informações sobre o bot:</i>

Feito em <b>PYTHON</b> teve sua primeira versão finalizada em <b>21/12/2024</b> após isso já houve grandes mudanças, mas sempre no intuído de trazer algo melhor ❤.

Sua versão atual é 2.0.0

Criador do bot @PHDASUL7

<b>Todas as atualizações e novidades são postadas no canal oficial de desenvolvimento deste bot.</b>""",
  reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex(r"swat$"))
async def dv(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            
            
             [
                 InlineKeyboardButton("Voltar", callback_data="start"),
             ],

        ]
    )

    await m.edit_message_text(
        f"""<a href='https://s4.aconvert.com/convert/p3r68-cdx67/amzgv-y7g9c.jpg'>&#8204</a><i>É um prazer te ver por aqui {m.from_user.first_name}, Divulgue seu link de indicação e ganhe R$ 1,00 por cada pessoa que você trouxer para o bot, Copie seu link entrando em "informações"</i>""",
  reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buy_history$"))
async def buy_history(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("Voltar", callback_data="user_info"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT number, month, year, cvv FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<i>🔕 Ops , Você Ainda não tem nenhuma Compra !</i>"
    else:
        cards = []
        for card in history:
            cards.append("|".join([i for i in card]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in cards])

    await m.edit_message_text(
        f"""✅ <b> Seus cartões</b>
{cards_txt}""",
        reply_markup=kb,
	)

@Client.on_callback_query(filters.regex(r"^ht$"))
async def buy_history(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("Voltar", callback_data="user_info"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT number, month, year, cvv FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<i>🔕 Ops , Você Ainda não tem nenhuma Compra !</i>"
    else:
        cards = []
        for card in history:
            cards.append("|".join([i for i in card]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in cards])

    await m.edit_message_text(
        f"""✅ <b> Seus cartões</b>
{cards_txt}""",
        reply_markup=kb,
	)

@Client.on_callback_query(filters.regex(r"^buy_history_log$"))
async def buy_history_log(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("Voltar", callback_data="user_info"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT tipo, email, senha, cidade bought_date FROM logins_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 0",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<i>🔕 Ops , Você Ainda não tem nenhum Login Comprado !</i>"
    else:
        documentos = []
        print(documentos)
        for card in history:
            documentos.append("|".join([i for i in card]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in documentos])

    await m.edit_message_text(
        f"""✅ <b> Seus Logins</b>
{cards_txt}""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^swap$"))
async def swap_points(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="start"),
            ],
        ]
    )

    user_id = m.from_user.id
    balance, diamonds = cur.execute(
        "SELECT balance, balance_diamonds FROM users WHERE id=?", [user_id]
    ).fetchone()

    if diamonds >= 50:
        add_saldo = round((diamonds / 2), 2)
        new_balance = round((balance + add_saldo), 2)

        txt = f"⚜️ Seus <b>{diamonds}</b> pontos foram convertidos em R$ <b>{add_saldo}</b> de saldo."

        cur.execute(
            "UPDATE users SET balance = ?, balance_diamonds=?  WHERE id = ?",
            [new_balance, 0, user_id],
        )
        return await m.edit_message_text(txt, reply_markup=kb)

    await m.answer(
        "⚠️ Você não tem pontos suficientes para realizar a troca. O mínimo é 100 pontos.",
        show_alert=True,
    )


   
@Client.on_callback_query(filters.regex(r"^swap_info$"))
async def swap_info(c: Client, m: CallbackQuery):
    await m.message.delete()

    cpf = await m.message.ask(
        "<b>👤 CPF da lara (exemplo: 30599385120)</b>",
        reply_markup=ForceReply(),
        timeout=120,
    )
    name = await m.message.ask(
        "<b>👤 Nome completo do pagador (exemplo: wilma bernadete de almeida borba)</b>", reply_markup=ForceReply(), timeout=120
    )
    email = await m.message.ask(
        "<b>📧 E-mail (exemplo: soucorno@gmail.com)</b>", reply_markup=ForceReply(), timeout=120
    )
    cpf, name, email = cpf.text, name.text, email.text
    cur.execute(
        "UPDATE users SET cpf = ?, name = ?, email = ?  WHERE id = ?",
        [cpf, name, email, m.from_user.id],
    )
    save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Voltar", callback_data="start"),
            ]
        ]
    )
    await m.message.reply_text(
        "<b> ✅ Seus dados foram alterados com sucesso.</b>", reply_markup=kb
	)