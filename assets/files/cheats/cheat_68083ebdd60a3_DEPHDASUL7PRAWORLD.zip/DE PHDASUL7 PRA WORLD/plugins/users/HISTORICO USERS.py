import io
from typing import Union

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

import sqlite3

db = sqlite3.connect("main.db")
cur = db.cursor()

@Client.on_message(filters.command(["history"]))
@Client.on_callback_query(filters.regex("^history$"))
async def history_menu(c: Client, m: Union[Message, CallbackQuery]):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("📂 Baixar Historico", callback_data="download_info"),
            ],
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="start"),
            ],
        ]
    )

    user_id = m.from_user.id

    # Calcula o total de cartões vendidos para o usuário
    total_cards = cur.execute("SELECT COUNT(*) FROM cards_sold WHERE owner = ?", [user_id]).fetchone()[0]

    # Obtém o saldo do usuário
    total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]

    # Calcula o total de recargas feitas pelo usuário
    total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [user_id]).fetchone()[0]

    # Calcula o total de gifts feitos pelo usuário
    total_gifts = cur.execute("SELECT COUNT(*) FROM gifts WHERE token IN (SELECT token FROM gifts WHERE value = ?)", [user_id]).fetchone()[0]

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text

    await send(
        f"""<b>📂 Histórico de transações:</b>\n<b>
💳 Cartões comprados: {total_cards}

💰 Saldo: R$ {total_balance}

💰 Recargas: {total_recargas}

🎁 Gifts resgatados: {total_gifts}

<b>⚠️ Atenção:  Os valores presentes nesta sessão, é o total comprado, adicionado e resgatado, respectivamente.</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r'^download_info$'))
async def download_info(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    
    # Obtém as informações do usuário
    user_info = cur.execute("SELECT id, balance FROM users WHERE id=?", [user_id]).fetchone()
    balance = user_info[1] if user_info else 0

    # Obtém os cartões vendidos (limite de 50)
    total_cards = cur.execute(
        'SELECT number, month, year, cvv, cpf, name, added_date, vendor, level, bank, country, bought_date FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 50',
        [user_id],
    ).fetchall()

    # Obtém os cartões full vendidos (limite de 50)
    total_full = cur.execute(
        'SELECT number, month, year, cvv, cpf, name, added_date, vendor, level, bank, country, bought_date FROM cards_sold_full WHERE owner = ? ORDER BY bought_date DESC LIMIT 50',
        [user_id],
    ).fetchall()

    # Obtém o saldo do usuário
    total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]

    # Calcula o total de recargas feitas pelo usuário
    total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [user_id]).fetchone()[0]

    # Calcula o total de gifts resgatados pelo usuário
    total_gifts = cur.execute("SELECT COUNT(*) FROM gifts WHERE token IN (SELECT token FROM gifts WHERE value = ?)", [user_id]).fetchone()[0]

    # Cria a mensagem personalizada para cartões comuns e full
    cards_info = ""
    if total_cards:
        cards_info += "𝗖𝗮𝗿𝘁𝗼𝗲𝘀 𝗔𝘂𝘅𝗶𝗹𝗶𝗮𝗿 𝗰𝗼𝗺𝗽𝗿𝗮𝗱𝗼𝘀:\n\n"
        for card in total_cards:
            cards_info += (
                f"📋 Número: {card[0]}\n"
                f"📆 Validade: {card[1]}/{card[2]}\n"
                f"🔐 CVV: {card[3]}\n"
                f"🏛 Banco: {card[9]}\n"
                f"💳 Bandeira: {card[7]}\n"
                f"💠 Nível: {card[8]}\n"
                f"🌍 País: {card[10]}\n"
                f"👤 Nome: {card[5]}\n"
                f"🪪 CPF: {card[4]}\n"
                f"📆 Comprado em: {card[11]}\n\n"
            )
    else:
        cards_info += "Nenhum cartão auxiliar comprado.\n"

    full_cards_info = ""
    if total_full:
        full_cards_info += "\n𝗖𝗮𝗿𝘁𝗼𝗲𝘀 𝗙𝘂𝗹𝗹 𝗰𝗼𝗺𝗽𝗿𝗮𝗱𝗼𝘀:\n\n"
        for card in total_full:
            full_cards_info += (
                f"📋 Número: {card[0]}\n"
                f"📆 Validade: {card[1]}/{card[2]}\n"
                f"🔐 CVV: {card[3]}\n"
                f"🏛 Banco: {card[9]}\n"
                f"💳 Bandeira: {card[7]}\n"
                f"💠 Nível: {card[8]}\n"
                f"🌍 País: {card[10]}\n"
                f"👤 Nome: {card[5]}\n"
                f"🪪 CPF: {card[4]}\n"
                f"📆 Comprado em: {card[11]}\n\n"
            )
    else:
        full_cards_info += "Nenhum cartão full comprado.\n"

    # Gera o texto final
    info_text = (
        f"✨️ Suas Informações\n📛 Nome: {m.from_user.first_name}\n🚫 Banido: Não\n👮‍♂️ Admin: Não\n🆔 ID da carteira: {user_id}\n💸 Saldo: R${balance}\n\n"
        f"{cards_info}"
        f"{full_cards_info}"
    )

    # Escreve as informações em um arquivo temporário
    with io.open(f'{user_id}.txt', 'w', encoding='utf-8') as f:
        f.write(info_text)

    # Envia o arquivo ao usuário
    await m.message.reply_document(
        document=f'{user_id}.txt',
        caption="Meu histórico",
    )