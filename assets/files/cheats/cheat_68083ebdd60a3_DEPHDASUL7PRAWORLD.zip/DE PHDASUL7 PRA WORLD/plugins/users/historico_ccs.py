import datetime
from pyrogram import Client, filters
from database import cur, save
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery, Message

# Função para obter os cartões vendidos das duas tabelas
def get_all_cards(user_id):
    # Obter cartões da tabela `cards_sold`
    cards_sold = cur.execute(
        'SELECT number, month, year, cvv, vendor, level, bank, country, name, cpf, bought_date '
        'FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC',
        [user_id]
    ).fetchall()

    # Obter cartões da tabela `cards_sold_full`
    cards_sold_full = cur.execute(
        'SELECT number, month, year, cvv, vendor, level, bank, country, name, cpf, bought_date '
        'FROM cards_sold_full WHERE owner = ? ORDER BY bought_date DESC',
        [user_id]
    ).fetchall()

    # Combinar ambas as listas de cartões
    return cards_sold + cards_sold_full

# Função para formatar os detalhes do cartão
def format_card_details(card, index, total_cards):
    # Formatar a data de compra
    bought_date = datetime.datetime.strptime(card[10], "%Y-%m-%d %H:%M:%S")
    formatted_date = bought_date.strftime("%d/%m/%Y às %H:%M:%S")
    
    return (
        f"✨<b>Detalhes do cartão</b>\n"
        f"💳 <b>Cartão:</b> <code>{card[0]}</code>\n"
        f"📆 <b>Validade:</b> <code>{card[1]}/{card[2]}</code>\n"
        f"🔐 <b>CVV:</b> <code>{card[3]}</code>\n\n"
        f"🏳️ <b>Bandeira:</b> <i>{card[4]}</i>\n"
        f"💠 <b>Nível:</b> <i>{card[5]}</i>\n"
        f"🏛 <b>Banco:</b> <i>{card[6]}</i>\n"
        f"🌍 <b>País:</b> <i>{card[7]}</i>\n\n"
        f"👤 <b>Nome:</b> <code>{card[8]}</code>\n"
        f"🪪 <b>CPF:</b> <code>{card[9]}</code>\n\n"
        f"📆 <b>Data de compra:</b> <i>{formatted_date}</i>\n"
        f"🔍 <b>Mostrando</b> <i>{index + 1}</i> <b>de</b> <i>{total_cards}</i>"
    )

# Callback para exibir o primeiro cartão e permitir navegação
@Client.on_callback_query(filters.regex(r'^show_cards$'))
async def show_cards(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    cards = get_all_cards(user_id)
    
    if not cards:
        await m.answer("⭕ Ops, você não comprou nenhum cartão.",show_alert=True,)
        return

    # Exibe o primeiro cartão da lista (índice 0)
    await show_card_details(c, m, index=0)

# Função para exibir os detalhes de um cartão específico com navegação
async def show_card_details(c: Client, m: CallbackQuery, index: int):
    user_id = m.from_user.id
    cards = get_all_cards(user_id)
    total_cards = len(cards)

    # Garantir que o índice esteja dentro do intervalo
    if index < 0:
        index = total_cards - 1  # Volta ao último cartão se estiver no começo
    elif index >= total_cards:
        index = 0  # Vai para o primeiro cartão se estiver no final

    # Pega o cartão atual
    card = cards[index]
    
    # Formata os detalhes do cartão
    card_details = format_card_details(card, index, total_cards)

    # Cria os botões de navegação
    buttons = [
        InlineKeyboardButton("‹‹", callback_data=f"navigate_card_{index-1}"),
        InlineKeyboardButton("››", callback_data=f"navigate_card_{index+1}")
    ]

    # Adiciona um botão separado abaixo dos botões de navegação
    extra_button = [InlineKeyboardButton("« Voltar", callback_data="user_info")]

    # Cria a marcação com os botões de navegação na primeira linha e o botão adicional em uma linha separada
    reply_markup = InlineKeyboardMarkup([buttons, extra_button])

    # Edita a mensagem com os detalhes do cartão e os botões de navegação
    await m.message.edit_text(
        card_details,
        reply_markup=reply_markup
    )

# Callback para navegar entre os cartões
@Client.on_callback_query(filters.regex(r'^navigate_card_\d+$'))
async def navigate_card(c: Client, m: CallbackQuery):
    # Obtém o índice do cartão a ser exibido a partir do callback_data
    index = int(m.data.split("_")[2])
    
    # Chama a função para exibir o cartão específico
    await show_card_details(c, m, index)

# Salva mudanças no banco de dados
save()