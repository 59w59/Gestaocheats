import sqlite3
import os
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import ADMINS

@Client.on_callback_query(filters.regex(r"^delete_database$") & filters.user(ADMINS))
async def delete_database(c: Client, m: CallbackQuery):
    try:
        os.remove("main.db")
        await m.answer("✅ Arquivo main.db excluído com sucesso.", show_alert=True)
    except Exception as e:
        await m.answer(f"❌ Ocorreu um erro ao excluir o arquivo main.db: {str(e)}", show_alert=True)