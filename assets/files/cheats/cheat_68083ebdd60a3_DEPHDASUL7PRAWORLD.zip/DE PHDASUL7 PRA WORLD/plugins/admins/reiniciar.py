from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
import asyncio

# Substitua [ID_DO_ADMIN] pelo ID do administrador
ADMIN_ID = 7396065035  # Coloque o ID do administrador aqui

@Client.on_callback_query(filters.regex(r'^ping$'))
async def ping(c: Client, m: CallbackQuery):
    await m.answer("⚠️ Reiniciando, aguarde... ao finalizar o precesso Nosso sistema mandará uma mensagem.", show_alert=True)
    await asyncio.sleep(7)  # Pausa por 7 segundos
    sent_message = await m.message.reply("<b>📣 Finalizado</b>")
    await sent_message.delete()  # Apaga a mensagem anterior
    inline_button = InlineKeyboardButton("🔧 PAINEL ADM", callback_data="painel")
    markup = InlineKeyboardMarkup([[inline_button]])
    await m.message.reply("<b>🤖 SEU BOT FOI REINICIADO!</b>", reply_markup=markup)
