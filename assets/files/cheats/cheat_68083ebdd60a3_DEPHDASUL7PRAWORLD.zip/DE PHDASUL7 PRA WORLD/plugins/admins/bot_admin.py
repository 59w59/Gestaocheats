import asyncio
import os
import sys
import utils as api
from typing import Union
from utils import create_mention

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import ADMINS, BOT_LINK, BOT_LINK_SUPORTE, get_admin_list, add_admin, remove_admin, load, save
from database import cur, save, db

user_responses = {}

@Client.on_callback_query(filters.regex("^bot_admin$") & filters.user(ADMINS))
async def bot_admin(c: Client, m: Union[Message, CallbackQuery]):

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("➕ Adicionar Administrador", callback_data="new_itslpk"),
            ],
            [
                InlineKeyboardButton("➖ Remover Administrador", callback_data="older_itslpk"),
            ],
            [
                InlineKeyboardButton("👮 Lista De Administradores", callback_data="list_blqt"),
            ],
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="painel"),
            ],
        ]
    )
    
    send = m.edit_message_text if isinstance(m, CallbackQuery) else m.reply_text
    
    await send(
        text=f"""<b>👮 Painel de Administradores.</b>
<i>- Selecione O Que Você Deseja Modificar.</i>
""",
        reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex("^new_itslpk$") & filters.user(ADMINS))
async def new_itslpk(c: Client, m: Union[Message, CallbackQuery]):
    if m.message:
        await m.message.delete()

    new_admin_message = await c.send_message(m.from_user.id, "<i>⚠️ Confirme se vc deseja promover este usuario ao cargo adminstrador enviando o id novamente, obs: este cargo é de grande responsabilidade </i>", reply_markup=ForceReply())

    # Aguarde a resposta do usuário
    response = await c.listen(filters=filters.text & filters.user(m.from_user.id))

    admin_id = response.text.strip()
    if add_admin(int(admin_id)):
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Voltar", callback_data="painel")]])
        await c.send_message(m.from_user.id, "<b>✅ Usuario promovido!!!</b>", reply_markup=markup)
    else:
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Voltar", callback_data="painel")]])
        await c.send_message(m.from_user.id, f"<b>⚠️ O ID {admin_id}, já é um administrador.</b>", reply_markup=markup)

@Client.on_callback_query(filters.regex("^older_itslpk$") & filters.user(ADMINS))
async def older_itslpk(c: Client, m: Union[Message, CallbackQuery]):
    if m.message:
        await m.message.delete()

    remove_admin_message = await c.send_message(m.from_user.id, "<i>❓ Confirme se vc deseja remover este usuario ao cargo adminstrador enviando o id novamente, obs: este cargo é de grande responsabilidade </i>", reply_markup=ForceReply())

    # Aguarde a resposta do usuário
    response = await c.listen(filters=filters.text & filters.user(m.from_user.id))

    admin_id = response.text.strip()
    if remove_admin(int(admin_id)):
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Voltar", callback_data="painel")]])
        await c.send_message(m.from_user.id, "<b>🚫 Usuario removido!!</b>", reply_markup=markup)
    else:
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Voltar", callback_data="painel")]])
        await c.send_message(m.from_user.id, f"<b>⚠️ O ID {admin_id} não é um administrador.</b>", reply_markup=markup)
        
@Client.on_callback_query(filters.regex("^list_blqt$") & filters.user(ADMINS))
async def list_blqt(c: Client, m: Union[Message, CallbackQuery]):
    admin_list = get_admin_list()

    if m.message:
        await m.message.delete()

    markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Voltar", callback_data="/painel")]])
    await c.send_message(m.message.chat.id, f"<b>Administradores: <code>{admin_list}</code></b>", reply_markup=markup)