from typing import Union

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import ADMINS
from database import cur, save

@Client.on_callback_query(filters.regex("^stockg$") & filters.user(ADMINS))
async def panel(c: Client, m: Union[Message, CallbackQuery]):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
              InlineKeyboardButton("💳 Estoque AUXILIAR", callback_data="stock cards"),
              InlineKeyboardButton("💳 Estoque CC FULL", callback_data="stockfull cards_full"),
            ],
            [
               InlineKeyboardButton("🎫 Estoque Logins", callback_data="stocklogins logins"),
               InlineKeyboardButton("💳 Estoque GG", callback_data="count_bins"),
            ],
            [
               InlineKeyboardButton("💳 Estoque Consul", callback_data="stockcon consul"),
            ],
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="painel"),
           ],   
      ]
 )

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text

    await send(
        """<b>📋 Painel De Estoques</b>
<i>Selecione Qual Você Vai Ver</i>""",
        reply_markup=kb,
    )