from pyrogram import Client, filters
import uuid
from config import ADMINS
from pyrogram.types import InlineQueryResultArticle, InputTextMessageContent, InlineKeyboardButton, InlineKeyboardMarkup
from database import cur, save
import sqlite3

@Client.on_inline_query(filters.user(ADMINS))  # Substitua admin_id pelo ID do administrador
async def inline_gift(client, inline_query):
    query = inline_query.query.strip()  # O que foi digitado na barra de busca inline

    # Verifica se o formato do query é válido (ex: "GERARGIFT 100")
    if query.startswith("GERARGIFT") and len(query.split()) == 2:
        try:
            gift_value = int(query.split()[1])  # Pega o valor do gift
        except ValueError:
            return  # Caso o valor não seja um número, ignore

        # Gera um token único para o gift
        token = str(uuid.uuid4())

        # Insere o gift no banco de dados
        cur.execute("INSERT INTO gifts (token, value) VALUES (?, ?)", (token, gift_value))
        save()

        # Prepara uma opção para criar o gift
        result = InlineQueryResultArticle(
            title=f"Gerar Gift de R${gift_value}",
            input_message_content=InputTextMessageContent(f"Gerando gift de R${gift_value}..."),
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("Resgatar", callback_data=f"redeem_gift|{token}|{gift_value}")]]
            ),
            description=f"Crie um gift no valor de R${gift_value}"
        )

        # Envia a resposta da consulta inline
        await client.answer_inline_query(inline_query.id, results=[result], cache_time=0)

@Client.on_callback_query(filters.regex(r"redeem_gift\|(\w+)\|(\d+)"))
async def redeem_gift(client, callback_query):
    token = callback_query.data.split("|")[1]
    gift_value = int(callback_query.data.split("|")[2])
    user_id = callback_query.from_user.id

    # Log para depuração
    print(f"Recebido callback: token={token}, gift_value={gift_value}, user_id={user_id}")

    try:
        # Verifica se o gift existe e não foi resgatado
        cur.execute("SELECT value FROM gifts WHERE token = ?", (token,))
        gift = cur.fetchone()

        if gift:
            # Atualiza o gift como resgatado
            cur.execute("DELETE FROM gifts WHERE token = ?", (token,))

            # Adiciona o saldo ao usuário
            cur.execute("UPDATE users SET balance = balance + ? WHERE id = ?", (gift_value, user_id))
            save()

            # Atualiza a mensagem no privado informando que o gift foi resgatado
            await callback_query.message.edit_text(f"Gift de R${gift_value} resgatado com sucesso! Seu saldo foi atualizado.")
        
        else:
            # Caso o gift não seja válido ou já tenha sido resgatado
            await callback_query.message.edit_text("Este gift não é válido ou já foi resgatado.")
    except Exception as e:
        # Caso ocorra um erro, exibe a mensagem de erro
        print(f"Erro ao processar callback: {e}")
        await callback_query.message.edit_text("Ocorreu um erro ao processar o gift. Tente novamente mais tarde.")