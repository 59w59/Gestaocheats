import ast

# CONFIGURAÇÃO APARTIR DA LINHA 50!

UP_FILE = 'config.py'

def save(key, value):
    with open(UP_FILE, 'r', encoding='utf-8', errors='replace') as file:
        lines = file.readlines()

    for i, line in enumerate(lines):
        if key in line and '=' in line:
            lines[i] = f"{key} = {value}\n"
            break

    with open(UP_FILE, 'w', encoding='utf-8', errors='replace') as file:
        file.writelines(lines)

def load(key):
    try:
        with open(UP_FILE, 'r', encoding='utf-8', errors='replace') as file:
            lines = file.readlines()
            for line in lines:
                if key in line and '=' in line:
                    value_part = line.split('=')[1].strip()
                    return [int(id.strip()) for id in value_part.strip('[]').split(',')]
    except (FileNotFoundError, ValueError):
        return []

def add_admin(admin_id):
    if admin_id not in ADMINS:
        ADMINS.append(admin_id)
        save("ADMINS", ADMINS)
        return True
    else:
        return False

def remove_admin(admin_id):
    if admin_id in ADMINS:
        ADMINS.remove(admin_id)
        save("ADMINS", ADMINS)
        return True
    else:
        return False
        
def get_admin_list():
    return ADMINS


# Token do seu Bot no telegram.
BOT_TOKEN = "7692348354:AAEwBHg8sLsqQZH-RD1gtn-Vv-3WjWXjQPg"

# Telegram API ID and Hash. This is NOT your bot token and shouldn't be changed. NÃO MEXA AQUI!
API_ID = 9641313
API_HASH = "baefb797b70643121704c7f344b92870"

# Chat used para notificar erros. (COLOQUE SEU ID)
LOG_CHAT = 6692194350

# Chat used for logging user ações (like buy, gift, etc).
ADMIN_CHAT = 6692194350
GRUPO_PUB = -1002478846292

# Chat de forçar entrada do start.py
CANAL_LINK = "worldvales"
CANAL_ID = -1002478846292

# Vecimento do bot
VENCIMENTO = '30-02-2025'

# How many updates can be handled in parallel.
# Don't use high values for low-end servers.
WORKERS = 20

# Admins can access panel and add new materials to the bot.
ADMINS = [6692194350]
ADMTEST = [6692194350]

# Sudoers have full access to the server and can execute commands.
SUDOERS = [6692194350]

# All sudoers should be admins too
ADMINS.extend(SUDOERS)

GIFTERS = []

# Bote o Username do bot sem o @
# Exemplo: fitcards_bot
BOT_LINK = "WorldStoreVales_bot"



# Bote o Username do suporte sem o @
# Exemplo: suporte
BOT_LINK_SUPORTE = "world77fornecedor"
##```
