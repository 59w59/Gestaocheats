from pyrogram import Client, filters
from pyrogram.types import Message, User
from database import cur, save
import random
import sqlite3
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

@Client.on_message(filters.command("transferir") & filters.private)
async def transferir_saldo(client, message):
    try:
        # Verifica se o comando foi digitado corretamente
        if len(message.command) < 3:
            await message.reply("<i>⚠️ Use o comando corretamente: /transferir id valor</i>")
            return

        # Extrai o ID do destinatário e o valor da transferência
        to_user_id = int(message.command[1])
        valor = float(message.command[2])
        from_user_id = message.from_user.id

        # Verifica se o ID do destinatário é válido
        user_exists = cur.execute("SELECT 1 FROM users WHERE id = ?", [to_user_id]).fetchone()
        if not user_exists:
            await message.reply("""<i>❌ | Erro Esse ID de usuário não foi encontrado</i>""")
            return

        # Verifica se o usuário que está transferindo o saldo tem saldo suficiente
        from_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [from_user_id]).fetchone()
        if not from_balance or from_balance[0] < valor:
            await message.reply("""<i>❌ | Erro Você não tem saldo suficiente para realizar a transferência!</i>""")
            return

        # Atualiza os saldos dos usuários
        cur.execute("UPDATE users SET balance = balance - ? WHERE id = ?", [valor, from_user_id])
        cur.execute("UPDATE users SET balance = balance + ? WHERE id = ?", [valor, to_user_id])
        save()

        # Notifica os usuários sobre a transferência
        from_user = await client.get_users(from_user_id)
        to_user = await client.get_users(to_user_id)
        await client.send_message(from_user_id, f"<i>✅️ Transferência realizada com sucesso! R$ {valor} foi enviado para {to_user.first_name}.</i>")
        await client.send_message(to_user_id, f"<i>✅️💰 Transferência recebida e #Aprovada! Valor: R$ {valor} do usuário {from_user.first_name}.</i>")
    except Exception as e:
        await message.reply(f"<b>Ocorreu um erro ao processar sua solicitação: {str(e)}</b>")
		
@Client.on_callback_query(filters.regex(r"^transfer_saldo$"))
async def transfer_saldo(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Voltar", callback_data="start"),
			],
		]
    )

    await m.edit_message_text(
        f"""<a href=''>&#8204</a><b>💰 | SISTEMA DE TRANSFERIR SALDO</b>

<i>🔀 AGORA E POSSIVEL TRANFERIR SEU SALDO ATUAL PARA UMA CONTA SECUNDARIA OU AMIGO.</i>

<i>🛍 OU VENDER SEU SALDO PARA OUTRO USUARIO QUE ESTEJA CADASTRADO EM NOSSA STORE</i>

<i>🔓 DIGITE /transferir (id) (valor) E PRONTO!!!</i>

<i>🧰 EXEMPLO</i> <code>/transferir 1949295097 20</code>""",
        reply_markup=kb,
	)
	