import json
import time
import asyncio

from config import BOT_LINK
from asyncio import sleep
from pyrogram import Client, filters
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

import datetime
from typing import Union
import asyncio

@Client.on_message(filters.command(["indicar"], ["/", "."]))
async def chaid(c: Client, m: Message):
    user_id = m.from_user.id
  
    # Adicionando um atraso de 7 segundos com a mensagem "Aguarde..."
    sent_message = await m.reply("<i>🗂 Gerando seu link de afiliado...</i>")
    await asyncio.sleep(3)
    await sent_message.delete()

    # Crie um botão inline com um link
    inline_button = InlineKeyboardButton("🔗 Compartilhar", callback_data="user_info")

    # Crie um teclado inline com o botão
    reply_markup = InlineKeyboardMarkup([[inline_button]])

    link = f"https://t.me/{c.me.username}?start={user_id}"
    await m.reply(
		f"""<i>🎁 Ganhe saldo apenas indicando novos usuarios para nossa loja!</i>
	
<i>💰 A cada usuario indicado vc ganha 1 de saldo</i>

🔗<b> Seu link de afiliado:</b> <code>{link}</code>

<i>📢 Clique no botão abaixo e divulgue seu link</i>""", reply_markup=reply_markup)