from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet, dobrosaldo
from config import BOT_LINK
from config import BOT_LINK_SUPORTE

app = Client("my_bot")

@Client.on_message(filters.command(["shop", "shop"]))
@Client.on_callback_query(filters.regex("^shop$"))
async def shop(c: Client, m: Union[Message, CallbackQuery]):
    mention = create_mention(m.from_user, with_id=False)
    user_id = m.from_user.id

    rt = cur.execute(
        "SELECT id, balance, balance_diamonds, refer FROM users WHERE id=?", [user_id]
    ).fetchone()

    if isinstance(m, Message):
        """refer = (
            int(m.command[1])
            if (len(m.command) == 2)
            and (m.command[1]).isdigit()
            and int(m.command[1]) != user_id
            else None
        )

        if rt[3] is None:
            if refer is not None:
                mention = create_mention(m.from_user, with_id=False)

                cur.execute("UPDATE users SET refer = ? WHERE id = ?", [refer, user_id])
                try:
                    await c.send_message(
                        refer,
                        text=f"<b>O usuário {mention} se tornou seu referenciado.</b>",
                    )
                except BadRequest:
                    pass"""

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🎫 Logins", callback_data="comprar_login unit"),
                InlineKeyboardButton("🎟️ Vales", callback_data="comprar_vales unit")
            ],
            [
                InlineKeyboardButton("💳 Auxiliar", callback_data="comprar_cc"),
                InlineKeyboardButton("💳 Full dados", callback_data="comprar_full"),
                InlineKeyboardButton("💳 Cartões GG", callback_data="ggs"),
            ],
			[
				InlineKeyboardButton("🏧 Consultada", callback_data="consulta"),
                InlineKeyboardButton("🏦 Consultável", callback_data="consul"),
			],
            [
                InlineKeyboardButton("🔱 Grupo Vip", callback_data="show_plans"),
            ],
            [
                InlineKeyboardButton("« Menu Principal", callback_data="start"),
            ],
            
        ]
    )

    bot_logo, news_channel, support_user = cur.execute(
        "SELECT main_img, channel_user, support_user FROM bot_config WHERE ROWID = 0"
    ).fetchone()

    start_message = f"""<a href=''>&#8204</a><b>• Full dados</b> <i>- Ccs com dados reais do titular do cartão.</i>
<b>• Dados auxiliares</b> <i>- Ccs com dados gerados do titular, não sendo real.</i>
<b>• Full dados</b> <i>- Dados reais do dono do cartão.</i>
<b>• Cartões GG</b> <i>- Cartões gerados.</i>
<b>• Logins</b> <i>- Logins quentes e antigos para facilitar suas aprovações.</i>
<b>• Vales</b> <i>- Vales com saldo para resgatar na loja e comprar qualquer produto.</i>
<b>• Consultada</b> <i>- São cartões com saldo consultado.</i>
<b>• Consultável</b> <i>- São cartões com acesso ao Aplicativo/Banco.</i>
<b>• Grupo Vip</b> <i>- Grupo/Canal com vários métodos e esquemas do 7!</i>

<b>Observação:</b> <i>Os dados que vem na cc são de reserva de hotel, logo e de praxe a pessoa que realiza reserva ou pessoa que tem o cartao adicional colocar seus dados.</i>

🛍️ <b>Escolha uma categoria:</b>
"""

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text
    save()
    await send(start_message, reply_markup=kb)
