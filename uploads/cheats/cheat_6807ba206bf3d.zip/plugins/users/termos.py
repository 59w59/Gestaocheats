from pyrogram import Client, filters
from pyrogram.types import Message
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

@Client.on_callback_query(filters.regex(r"^termos$"))
async def termos(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("✅️ Concordo", callback_data="start"),
			],
		]
    )

    await m.edit_message_text(
        f"""<a href=''>&#8204</a>‌<b>LEIA COM ATENCÃO</b>

<b>💳 Regras Info CC Auxiliar</b>

• Garanto a CC 100% Live
• Não garanto saldo na cc
• Não garanto seu esquema ou trampo
• As cc Auxiliares não são entregue com dados por conta que não cai cpf e nome
• Compre a CC sabendo que ela pode ir com 00,00$ a um saldo bom entre o limite da cc, cada cc tem seu limite
• A troca é feita apenas na loja, não troco info live no privado o tempo de troca são 5 minutos na loja


<b>💳 Regras CC full</b>

• Garanto a CC 100% Live
• Não garanto saldo na cc
• Não garanto seu esquema ou trampo
• Os dados entregue junto a cc são do dono do cartão
• Compre a CC sabendo que ela pode ir com 00,00$ a um saldo bom entre o limite da cc, cada cc tem seu limite
• A troca é feita apenas na loja, não troco info live no privado o tempo de troca são 5 minutos na loja


<b>💳 Regras Consultáveis em geral</b>

• 10 minutos para acessar o material conferir limite, compras, seguranças etc
• 1H para troca por cvv, data, acordo, com o banco direto com o especialista.
• Não aceito print ou vídeo de chat como troca
• Consultável com o limite inferior não troco, mando um desconto no valor da tabela
• Acesse o material com 4g FIXO! se usar WI-FI pra acessar perde a troca 
• Não troco material blocado no 1 acessado com WI-FI 
• Se caso o material for sem CPF, NOME bastar baixa uma fatura em PDF 
• As Flexíveis estão marcando um saldo de 100000 na loja, já compre sabendo elas tem em média a 5, 8, 50, 60, etc de limite isso varia de acordo com o dono e a fatura
• Ao realizar a compra do material verifique se ela está desbloqueado para compras On-line em serviços minhas proteções

<b>💳 Regras de reembolso caso houver</b>

• - 10% do valor do seu pix 
• - 2,99 de taxa de envio""",
        reply_markup=kb,
	)