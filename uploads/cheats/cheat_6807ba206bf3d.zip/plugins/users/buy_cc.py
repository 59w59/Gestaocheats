import asyncio
import random
from .start import start  # Importa a função start do módulo start.py
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultPhoto,
    InlineQueryResultArticle,
    InputTextMessageContent,
)

from config import ADMIN_CHAT
from config import GRUPO_PUB
from config import BOT_LINK
from config import BOT_LINK_SUPORTE
from database import cur, save
from utils import (
    create_mention,
    get_info_wallet,
    get_price,
    insert_buy_sold,
    insert_sold_balance,
    lock_user_buy,
    msg_buy_off_user,
    msg_buy_user,
    msg_group_adm,
    msg_group_publico,
)

from ..admins.panel_items.select_gate import GATES

gates = GATES

SELLERS, TESTED = 0, 0

gates_is_on = True if (len(gates) >= 1) else False
T = 0.1


async def chking(card):
    global gates, gates_is_on, T
    name_chk, _ = cur.execute(
        "SELECT gate_chk, gate_exchange FROM bot_config"
    ).fetchone()
    if name_chk == "pre-auth":
        T = 2
    else:
        T = 0.1

    return await gates[name_chk](card)


def rate_ccs():
    global SELLERS, TESTED
    rate = (SELLERS / TESTED) * 100
    return rate


# Listagem de tipos de compra.
@Client.on_callback_query(filters.regex(r"^comprar_cc$"))
async def comprar_cc_list(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("💳 Unitárias", callback_data="comprar_cc unit"),
                
                #InlineKeyboardButton("📦 Mix", callback_data="comprar_cc mix"),
            ],
            [
                InlineKeyboardButton(
                    "🏦 Buscar banco",
                    switch_inline_query_current_chat="buscar_banco BANCO",
                ),
                InlineKeyboardButton(
                    "🔍 Buscar bin",
                    switch_inline_query_current_chat="buscar_bin 550209",
                ),
            ],
            [
                InlineKeyboardButton(
                    "🇧🇷 Buscar bandeira",
                    switch_inline_query_current_chat="buscar_bandeira MASTERCARD",
                ),
            ],
[
                InlineKeyboardButton(
                    "🌎 Buscar países",
                    switch_inline_query_current_chat="buscar_paises BR",
                ),
            ],
            [
                InlineKeyboardButton("« Voltar", callback_data="shop"),
            ],
        ]
    )

    await m.edit_message_text(
        f"""<b>💳 Comprar CC's Auxiliar</b>
        
<i>⚠️ Compre apenas se você estiver de acordo com as regras:</i>

<b>✅ | GARANTIMOS LIVE!
Não asseguramos saldo específico ou aprovação.

💎 | Direito de troca em até 10 minutos automaticamente através do bot. Caso a troca não seja efetuada, por favor, não insista!

⚙️ | Utilizamos um checker assertivo, realizando uma pré-verificação no cartão.

🛒 | Destacamo-nos como uma das únicas lojas que trabalham com material pré-selecionado, proveniente de admins.</b>

<i>- Escolha abaixo o produto que deseja comprar.</i>

{get_info_wallet(m.from_user.id)}""",
        reply_markup=kb,
    )


# Dicionário que mapeia bandeiras de cartão às URLs das imagens correspondentes
card_images = {
    "mastercard": "https://i.ibb.co/XX0jDDQ/images-15.jpg",
    "visa": "https://i.ibb.co/BCPMKQ8/images-16.jpg",
    "elo": "https://i.ibb.co/fxrWpWF/images-6.png",
	"amex": "https://i.ibb.co/C7VyV9y/images-7.png",
	"elo/discover": "https://i.ibb.co/PYz96Sj/DGN-Acceptance-Mark.png",
    # Adicione mais bandeiras e URLs conforme necessário
}

# Pesquisa de CCs via inline.
@Client.on_inline_query(filters.regex(r"^buscar_(?P<type>\w+) (?P<value>.+)"))
async def search_cc(c: Client, m: InlineQuery):
    """
    Pesquisa uma CC via inline por tipo e retorna os resultados via inline.

    O parâmetro type será o tipo de valor para pesquisar, ex.:
        bin (Por bin), bank (Por banco), vendor (Por bandeira), etc.
    O parâmetro value será o valor para pesquisa, ex.:
        550209 (Bin), Nubank (Banco), Mastercard (Bandeira), etc.
    """

    typ = m.matches[0]["type"]
    qry = m.matches[0]["value"]

    # Não aceitar outros valores para prevenir SQL Injection.
    if typ not in ("bin", "banco", "bandeira", "paises"):
        return

    if typ != "bin":
        qry = f"%{qry}%"

    if typ == "banco":
        typ2 = "bank"
    elif typ == "bandeira":
        typ2 = "vendor"
    elif typ == "paises":
        typ2 = "country"
    else:
        typ2 = typ

    rt = cur.execute(
        f"SELECT number, month, year, {typ2}, country FROM cards WHERE {typ2} LIKE ? AND pending = 0 ORDER BY RANDOM() LIMIT 50",
        [qry.upper()],
    ).fetchall()

    results = []

    wallet_info = get_info_wallet(m.from_user.id)

    for number, month, year, value, country in rt:
        price = await get_price("bin", number[0:6])

        base = f"""💳 Cartão: {number[0:6]}**
📅 Validade: {month}/{year}
🔐 Cvv: ***"""

        base_ml = f"""<b>Cartão:</b> <i>{number[0:6]}**</i>
<b>Validade:</b> <i>{month}/{year}</i>
<b>Cvv:</b> <i>***</i>

<b>Valor:</b> <i>R$ {price}</i>"""

		# Determina a URL da imagem com base na bandeira do cartão
        photo_url = card_images.get(value.lower(), "https://i.ibb.co/Y31rfn7/images-13.jpg")
		
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="✅ Comprar",
                        callback_data=f"comprar_cc bin '{number[0:6]}' {month}|{year}",
                    )
                ]
            ]
		)
		
        # Adiciona um resultado com uma imagem
        results.append(
            InlineQueryResultPhoto(
                id=str(number),
                photo_url=photo_url,  # URL da imagem a ser mostrada
                thumb_url=photo_url,  # URL da miniatura da imagem
                title=f"{typ} {value} - R$ {price}",
                description=base,
				input_message_content=InputTextMessageContent(
                    base_ml + "\n\n" + wallet_info
                ),
				reply_markup=kb,
            )
        )
		
        await m.answer(results, cache_time=5, is_personal=True)

		
# Opção Compra de CCs e Listagem de Level's.
@Client.on_callback_query(filters.regex(r"^comprar_cc unit$"))
async def comprar_ccs(c: Client, m: CallbackQuery):
    list_levels_cards = cur.execute("SELECT level FROM cards GROUP BY level").fetchall()
    levels_list = [x[0] for x in list_levels_cards]

    if not levels_list:
        return await m.answer(
            "⭕️ Sem Estoque",
            show_alert=True,
        )

    levels = []
    for level in levels_list:
        level_name = level
        n = level.split()
        if len(n) > 1:
            level_name = n[0][:3] + " " + n[1]

        price = await get_price("unit", level)
        levels.append(
            InlineKeyboardButton(
                text=f"{level_name} | R${price} ",
                callback_data=f"comprar_cc unit '{level}'",
            )
        )

    organ = (
        lambda data, step: [data[x : x + step] for x in range(0, len(data), step)]
    )(levels, 2)
    table_name = "cards"
    cards = cur.execute(
        f"SELECT level, count() FROM {table_name} GROUP BY level ORDER BY count() DESC"
    ).fetchall()

    stock = (
        '\n'.join([f'<b>{it[0]}</b>: {it[1]}' for it in cards])
        or '<b>Nenhum item nesta categoria.</b>'
    )

    total = f"{sum([int(x[1]) for x in cards])}" if cards else ""

    organ.append([InlineKeyboardButton(text="« Voltar", callback_data="comprar_cc")])
    kb = InlineKeyboardMarkup(inline_keyboard=organ)
    await m.edit_message_text(
        f"""<b>💳 Comprar Unitária</b>
<i>- Selecione o nível da CC desejada.</i>

<b>Status Checker:</b> <i>Ativo ✅</i>
<b>Promoção:</b> <i>Ativa ✅</i>
<b>Pix automático:</b> <i>Ativo ✅</i>

<code>🗂️ Há {total} cartões disponíveis!</code>

{get_info_wallet(m.from_user.id)}""",
        reply_markup=kb,
    )

@Client.on_callback_query(
    filters.regex(
        r"^comprar_cc (?P<type>[a-z]+) '(?P<level_cc>.+)' ?(?P<other_params>.+)?"
    )
)

async def buy_final(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    balance: int = cur.execute(
        "SELECT balance FROM users WHERE id = ?", [user_id]
    ).fetchone()[0]

    type_cc = m.matches[0]["type"]
    level_cc = m.matches[0]["level_cc"]
    
    # Criar uma lista com todas as ccs disponíveis para esse nível
    ccs_list = cur.execute(
        f"SELECT number, month, year, cvv, level, added_date, vendor, bank, country, cpf, name FROM cards WHERE level = ? AND pending = ? ORDER BY RANDOM()",
        [level_cc, False],
    ).fetchall()

	# Verificar se há alguma cc disponível e, se não, retornar uma mensagem informando ao usuário
    if not ccs_list:
        return await m.answer("⭕️ Sem Estoque")

    # Exibir quantas ccs estão disponíveis
    num_ccs = len(ccs_list)
    current_cc = 0  # Definir a variável com valor zero
    await m.answer(f"Estoque ({current_cc}/{num_ccs})")

    # Selecionar uma cc aleatória dessa lista
    ccs = random.choice(ccs_list)

    # Obter as informações relevantes dessa cc
    card_bin = ccs[0]
    date = f"{ccs[1]}/{ccs[2]}"
    ano = ccs[2]
    vendor = ccs[6]
    bank = ccs[7]
    country = ccs[8]  # Adicionado para obter o país
    

    # Obtém o tipo de cartão da tabela "cards"
    card_number = ccs[0]
    result = cur.execute("SELECT card_type FROM cards WHERE bin = ? AND pending = ? LIMIT 1", [card_number[:6], False]).fetchone()
    if result is not None:
        card_type = result[0]
    else:
        card_type = "Desconhecido"

    # Imprime o card_type para verificar se está sendo setado
    print(f"card_type: {card_type}")

    # Definir o preço com base no tipo de compra
    price = await get_price(type_cc, level_cc)
    if type_cc != "unit":
        price = price * 10

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("✅", callback_data="continue"),
                InlineKeyboardButton("➡️", callback_data="proximo_card"),
            ],
            [
                InlineKeyboardButton("🔻 Voltar", callback_data="start"), # Alterado para "start"
            ]
        ]
    )

    if type_cc != "unit":
        await c.edit_message_text(
            user_id,
            f"""
<b>🔎 Mostrando</b><i>({current_cc}/{num_ccs})</i>

<i>✨️ Detalhes do cartão</i>

<b>💳 Cartão:</b> <i>{card_bin[0:6]}**********</i>
<b>🏦 Banco:</b> <i>{bank} </i>
<b>📅 Expiração:</b> <i>{date} </i>
<b>🏳 Bandeira:</b> <i>{vendor} </i>

<b>💠 Nível:</b> <i>{level_cc} </i>
<b>🏳️‍🌈 País:</b> <i>{country} </i>  
<b>💰 Valor:</b> <i>R${price} </i>
            
{get_info_wallet(m.from_user.id)}""",
            reply_markup=kb,
        )

    else:
        await m.edit_message_text(
            f"""
<b>🔎 Mostrando</b><i>({current_cc}/{num_ccs})</i>

<i>✨️ Detalhes do cartão</i>

<b>💳 Cartão:</b> <i>{card_bin[0:6]}**********</i>
<b>🏦 Banco:</b> <i>{bank} </i>
<b>📅 Expiração:</b> <i>{date} </i>
<b>🏳 Bandeira:</b> <i>{vendor} </i>

<b>💠 Nível:</b> <i>{level_cc} </i>
<b>🏳️‍🌈 País:</b> <i>{country} </i>  
<b>💰 Valor:</b> <i>R${price} </i>
            
{get_info_wallet(m.from_user.id)}""",
            reply_markup=kb,
        )


    # Esperar por novos callbacks
    while True:
        m = await c.wait_for_callback_query(chat_id=user_id)

        if m.data == "continue":
            # Atualizar contagem das ccs exibidas
            current_cc += 1

            if current_cc > num_ccs:
                current_cc = 1

            # ...
            break

        elif m.data == "start":
            return  await start(c, m)



        elif m.data == "proximo_card":
            # Atualizar contagem das ccs exibidas
            current_cc += 1

            if current_cc > num_ccs:
                current_cc = 1

            # Selecionar uma cc aleatória dessa lista
            ccs = random.choice(ccs_list)

            # Obter as informações relevantes dessa cc
            card_bin = ccs[0]
            date = f"{ccs[1]}/{ccs[2]}"
            ano = ccs[2]
            vendor = ccs[6]
            bank = ccs[7]
            country = ccs[8]  # Adicionado para obter o país
            # Definir o preço com base no tipo de compra
            price = await get_price(type_cc, level_cc)
            if type_cc != "unit":
                price = price * 10

            # Atualizar a mensagem com as informações do novo cartão e contagem de ccs
            if type_cc != "unit":
                await c.edit_message_text(
                    user_id,
                    f"""
<b>🔎 Mostrando</b><i>({current_cc}/{num_ccs})</i>

<i>✨️ Detalhes do cartão</i>

<b>💳 Cartão:</b> <i>{card_bin[0:6]}**********</i>
<b>🏦 Banco:</b> <i>{bank} </i>
<b>📅 Expiração:</b> <i>{date} </i>
<b>🏳 Bandeira:</b> <i>{vendor} </i>

<b>💠 Nível:</b> <i>{level_cc} </i>
<b>🏳️‍🌈 País:</b> <i>{country} </i>  
<b>💰 Valor:</b> <i>R${price} </i>

{get_info_wallet(m.from_user.id)}""",
                    reply_markup=kb,
                )

            else:
                await m.edit_message_text(
                    f"""
<b>🔎 Mostrando</b><i>({current_cc}/{num_ccs})</i>

<i>✨️ Detalhes do cartão</i>

<b>💳 Cartão:</b> <i>{card_bin[0:6]}**********</i>
<b>🏦 Banco:</b> <i>{bank} </i>
<b>📅 Expiração:</b> <i>{date} </i>
<b>🏳 Bandeira:</b> <i>{vendor} </i>

<b>💠 Nível:</b> <i>{level_cc} </i>
<b>🏳️‍🌈 País:</b> <i>{country} </i>  
<b>💰 Valor:</b> <i>R${price} </i>

{get_info_wallet(m.from_user.id)}""",
                    reply_markup=kb,
                )

    if balance < price: # verificar se o usuário tem saldo suficiente para realizar a compra
        return await m.answer(
            "⭕️ Saldo Insuficiente",
            show_alert=False,
        )

    search_for = "level" if type_cc == "unit" else "bin"

    ccs_list = cur.execute(
        f"SELECT number, month, year, cvv, level, added_date, vendor, bank, country, cpf, name FROM cards WHERE {search_for} = ? AND pending = ? ORDER BY RANDOM() LIMIT 20",
        [level_cc, False],
    ).fetchall()

    if gates_is_on:
        live = 0
        await m.edit_message_text(
            "<b>⏰ Por favor, aguarde enquanto realizo a verificação do status do seu cc.</b>"
        )
        for tp in ccs_list:
            (
                number,
                month,
                year,
                cvv,
                level,
                added_date,
                vendor,
                bank,
                country,
                cpf,
                name,
            ) = tp

            card = "|".join([number, month, year, cvv])
            is_pending = cur.execute(
                "SELECT pending FROM cards WHERE number = ?", [tp[0]]
            ).fetchone()
            # Se retornar None, a cc já foi vendida ou marcada die.
            # Se is_pending[0] for True, ela está sendo verificada por outro processo.
            if not is_pending or is_pending[0]:
                continue
            cur.execute("UPDATE cards SET pending = 1 WHERE number = ?", [tp[0]])
            live_or_die = await chking(card)
            # live_or_die = (True, "test-gate")
            await asyncio.sleep(T)

            list_dados = tp + (user_id, type_cc, True)

            if live_or_die[0]:  # caso venha cc live
                diamonds = (price / 100) * 8
                new_balance = round(balance - price, 2)

                cur.execute(
                    "UPDATE users SET balance = round(balance - ?, 2), balance_diamonds = round(balance_diamonds + ?, 2) WHERE id = ?",
                    [price, diamonds, user_id],
                )
                dados = (cpf, name) if cpf != None else None
                base = await msg_buy_user(
                    user_id,
                    card,
                    vendor,
                    country,
                    bank,
                    level_cc,
                    price,
                    diamonds,
                    dados,
                )

                cur.execute(
                    "DELETE FROM cards WHERE number = ?",
                    [tp[0]],
                )

                insert_buy_sold(list_dados)
                insert_sold_balance(price, user_id, "cards")

                kb = InlineKeyboardMarkup(
				   inline_keyboard=[
				       [
				           InlineKeyboardButton(
		                       text="🗑️ Excluir",
		                       callback_data="menu2"
		                    ),
		                ],
		             ]
		        )

                await m.edit_message_text(base, reply_markup=kb)

                mention = create_mention(m.from_user)

                adm_msg = msg_group_adm(
                    mention,
                    card,
                    level_cc,
                    type_cc,
                    price,
                    live_or_die[1],
                    new_balance,
                    vendor,
                )
                await c.send_message(ADMIN_CHAT, adm_msg)
                
                kb = InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="🤖 Resgistre-se",url=f"https://t.me/{BOT_LINK}"
                            ),
                        ],
                    ]
                )
                mention = m.from_user.first_name
                
                adm_msg = msg_group_publico(
                    mention,
                    card,
                    level_cc,
                    type_cc,
                    price,
                    live_or_die[1],
                    new_balance,
                    vendor,
                )
                await c.send_message(GRUPO_PUB, adm_msg, reply_markup=kb)
                
                

                kb = InlineKeyboardMarkup(
                    inline_keyboard=[
                        [
                            InlineKeyboardButton(
                                text="⚠️ Support", url="t.me/imjokerofc"
                            ),
                        ],
                    ]
                )
                try:
                    await m.message.reply_text(
                        "<b>⛔ Material estava die?</b>",
                        reply_markup=kb,
                    )
                except:
                    ...
                save()
                return

            elif live_or_die[0] is None:  # ccs type return None
                cur.execute(
                    "UPDATE cards SET pending = False WHERE number = ?", [tp[0]]
                )

            else:  # para ccs_die
                cur.execute(
                    "DELETE FROM cards WHERE number = ?",
                    [tp[0]],
                )
                values = "number, month, year, cvv, level, added_date, vendor, bank, country, cpf, name, plan"
                list_dies = tp + (type_cc,)
                cur.execute(
                    f"INSERT INTO cards_dies({values}) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    list_dies,
                )

        if (live == 0) and gates_is_on:
            txt = "❗️ Não consegui achar CCs lives deste nível na minha database. Tente novamente com outro nível ou bin."
            kb = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🔙 Voltar", callback_data="comprar_cc unit"
                        ),
                    ],
                ]
            )
        else:
            txt = (
                "⚠️ Parece que todas as gates do bot esão offline, você deseja continuar ou tentar novamente?\n"
                "Ao continuar, sua compra será efetuada <b>sem verificar</b>, ou seja, ela <b>não possuirá troca</b>."
            )
            kb = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="🔁 Tentar novamente",
                            callback_data=m.data,
                        ),
                        InlineKeyboardButton(
                            text="✅ Continuar",
                            callback_data=f"buy_off {type_cc} '{level_cc}'",
                        ),
                    ],
                    [
                        InlineKeyboardButton(text="🔙 Voltar", callback_data="comprar_cc unit"),
                    ],
                ]
            )
        await m.edit_message_text(txt, reply_markup=kb)

    # operação de venda caso as gates estejam off
    else:
        txt = (
            "⚠️ Parece que todas as gates do bot esão offline, você deseja continuar?\n"
            "Ao continuar, sua compra será efetuada <b>sem verificar</b>, ou seja, ela <b>não possuirá troca</b>."
        )
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="✅ Continuar",
                        callback_data=f"buy_off {type_cc} '{level_cc}'",
                    ),
                    InlineKeyboardButton(text="🔙 Voltar", callback_data="comprar_cc unit"),
                ],
            ]
        )
        await m.edit_message_text(txt, reply_markup=kb)

    save()


@Client.on_callback_query(
    filters.regex(r"^buy_off (?P<type>[a-z]+) '(?P<level_cc>.+)' ?(?P<other_params>.+)?")  # fmt: skip
)
@lock_user_buy
async def buy_off(c: Client, m: CallbackQuery):
    user_id = m.from_user.id
    balance: int = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]  # fmt: skip

    type_cc = m.matches[0]["type"]
    level_cc = m.matches[0]["level_cc"]

    price = await get_price(type_cc, level_cc)

    if balance < price:
        return await m.answer(
            "⚠️ Você não possui saldo suficiente para esse item. Por favor, faça uma transferência.",
            show_alert=True,
        )

    search_for = "level" if type_cc == "unit" else "bin"

    selected_cc = cur.execute(
        f"SELECT number, month, year, cvv, level, added_date, vendor, bank, country, cpf, name FROM cards WHERE {search_for} = ? AND pending = ? ORDER BY RANDOM()",
        [level_cc, False],
    ).fetchone()

    if not selected_cc:
        return await m.answer("⚠️ Sem CCs disponiveis para este nivel.", show_alert=True)

    diamonds = round(((price / 100) * 8), 2)
    new_balance = balance - price

    (
        number,
        month,
        year,
        cvv,
        level,
        added_date,
        vendor,
        bank,
        country,
        cpf,
        name,
    ) = selected_cc

    card = "|".join([number, month, year, cvv])

    list_card_sold = selected_cc + (user_id, type_cc, False)

    cur.execute(
        "DELETE FROM cards WHERE number = ?",
        [selected_cc[0]],
    )

    cur.execute(
        "UPDATE users SET balance = ?, balance_diamonds = round(balance_diamonds + ?, 2) WHERE id = ?",
        [new_balance, diamonds, user_id],
    )

    insert_buy_sold(list_card_sold)
    insert_sold_balance(price, user_id, "cards")

    dados = (cpf, name) if cpf is not None else None
    base = await msg_buy_off_user(
        user_id, card, vendor, country, bank, level_cc, price, diamonds, dados
    )
    await m.edit_message_text(base)
    mention = create_mention(m.from_user)
    adm_msg = msg_group_adm(
        mention, card, level_cc, type_cc, price, "None", new_balance, vendor
    )
    await c.send_message(ADMIN_CHAT, adm_msg)

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🔙", callback_data="shop"),
            ],
        ]
    )
    try:
        await m.message.reply_text(
            "✅ Compra realizada com sucesso. Clique no botão abaixo para voltar para o menu principal.",
            reply_markup=kb,
        )
    except:
        ...
    save()