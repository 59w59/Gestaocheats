import os
import sys
import asyncio
from typing import Union

from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from config import ADMINS
from database import cur, save

@Client.on_message(filters.command("painel") & filters.user(ADMINS))
@Client.on_callback_query(filters.regex("^painel$") & filters.user(ADMINS))
async def panel(c: Client, m: Union[Message, CallbackQuery]):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🚦Manutenção", callback_data="bot_status"),
                InlineKeyboardButton("🏦 Lara", callback_data="change_lara"),
            ],
            [
                InlineKeyboardButton("💠 Pix auto", callback_data="auto_pay"),
            ],
            [
                InlineKeyboardButton("⚙️ Trocar Gates", callback_data="select_gate"),
                InlineKeyboardButton("💸 Preços", callback_data="change_prices"),
            ],
            [
            InlineKeyboardButton("👮‍♂️ Admins", callback_data="bot_admin"),
            #InlineKeyboardButton("🔄🤖 REINICIAR STORE", callback_data="ping"),
            ],
            [
            InlineKeyboardButton("👤 Configurar Usuários", callback_data="configurar_usuarios"),
            InlineKeyboardButton("☢️ Menu SQL", callback_data="menu_sql"),
            ],
            [
            InlineKeyboardButton("🌐 Menu de comandos", callback_data="cmd"),
            ],
            [
               InlineKeyboardButton("📊 Estoque", callback_data="stockg"),
               InlineKeyboardButton("🛠 Outras configs", callback_data="bot_config"),
           ],
        ]
    )

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text

    table_name = "users"
    users_count = cur.execute(f"SELECT COUNT(DISTINCT id) FROM {table_name}").fetchone()[0]
    total = f"<b>👤 Registrados:</b> {users_count}"

    await send(
        text=f"""<b>🛠 CONFIGURAÇÕES GERAL
Painel admin atualizado para versão 2.0 onde inclui várias utilidades para o administrador.

👮‍♀️ Admin: Não 
💼 Dono: Sim
🏦 Pix Aut: null

{total}</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^delete_session$") & filters.user(ADMINS))
async def delete_session(c: Client, m: CallbackQuery):
    try:
        os.remove("bot.session")
        await m.answer("✅ Arquivo bot.session excluído com sucesso.", show_alert=True)
    except Exception as e:
        await m.answer(f"❌ Ocorreu um erro ao excluir o arquivo bot.session: {str(e)}", show_alert=True)

@Client.on_callback_query(filters.regex(r"^restart_store$") & filters.user(ADMINS))
async def restart_store(c: Client, m: CallbackQuery):
    await m.answer("⚠️ Reiniciando base...", show_alert=True)
    
    # Aguarde um curto período de tempo para que a mensagem de alerta seja exibida
    await asyncio.sleep(2)
    
    os.execl(sys.executable, sys.executable, *sys.argv)
    
@Client.on_callback_query(filters.regex("^configurar_usuarios$") & filters.user(ADMINS))
async def configurar_usuarios(c: Client, m: Union[Message, CallbackQuery]):

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🔍 Pesquisar", switch_inline_query_current_chat="search_user"),
            ],
            [
                InlineKeyboardButton("🎃 Dobro Saldo", callback_data="dobro"),
            ],
            [
                #InlineKeyboardButton("🎁 Bônus de registro", callback_data="set_bonus"),
            ],
            [
                InlineKeyboardButton("⬅️ Voltar", callback_data="painel"),
            ],
        ]
    )
    
    send = m.edit_message_text if isinstance(m, CallbackQuery) else m.reply_text
    
    await send(
        text=f"""🔎 <b>PESQUISAR USUÁRIO</b>\n<i>Se este usuário estiver registrado no bot, vai abrir as configurações de edição desse usuário.</i>\n<i>Você poderá editar o saldo, ver o histórico de compras, e todas as informações dele.</i>\n\n<b>🎃 DOBRO SALDO</b>\n<i>Dobra o saldo após o usuário realizar uma recarga via pix!</i>\n\n<b>🎁 BÔNUS DE REGISTRO</b>\n<i>Bônus de registro é o valor que cada usuário novo ganhará apenas por se registrar, é um bônus de boas-vindas.</i>\nUse: <code>/set_bonus</code> Para não dar bônus nenhum, deixe em 0.
""",
        reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex("^menu_sql$") & filters.user(ADMINS))
async def menu_sql(c: Client, m: Union[Message, CallbackQuery]):

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🗑 Delatar Arquivo Session", callback_data="delete_session"),
            ],
            [
                InlineKeyboardButton("🗂 Deletar Arquivo main.db", callback_data="delete_database"),
            ],
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="painel"),
            ],
        ]
    )
    
    send = m.edit_message_text if isinstance(m, CallbackQuery) else m.reply_text
    
    await send(
        text=f"""<b>☢️ Menu SQL.</b>
<i>- Aqui você pode apagar o bot completo! histórico de usuários, saldos, estoque. Atenção, após clicar tudo será apagado!</i>
""",
        reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex("^cmd$") & filters.user(ADMINS))
async def bot_admin(c: Client, m: Union[Message, CallbackQuery]):

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Voltar", callback_data="painel"),
            ],
        ]
    )
    
    send = m.edit_message_text if isinstance(m, CallbackQuery) else m.reply_text
    
    await send(
        text=f"""<b>⚙️Ⓜ️ Menu de comandos disponíveis na Store!</b>

/start - MENU DO BOT
/pix - ADICIONAR SALDO
/resgatar - RESGATAR GIFTERS
/ticket - ABRE UM TICKET DE SUPORTE E CHEGA NOTIFY PRA VOCÊ!
/gift - GERAR GIFTER (ADM)
/painel - PAINEL DO BOT (ADM)
/done - SAIR DO MODO ADIÃ‡ÃƒO (ADM)
/adc - ADICIONAR AUXILIAR (ADM)
/full - ADICIONAR CCS FULL (ADM)
/gg - ADICIONAR GG'S (ADM)
/login - ADICIONAR LOGINS (ADM)
/vales - ADICIONAR VALES (ADM)
/consultadaadd - ADICIONAR CONSULTADA (ADM)
/consultaveladd - ADICIONAR CONSULTAVEL (ADM)
/enviar - ENVIAR MENSAGEM NO CHAT DO BOT (ADM)
/cancel - CANCELAR COMANDO (TODOS)

<b>☢️ COMANDOS QUE SÓ VAI PEGAR NO GRUPO!</b>

/resaldo - TIRA SALDO DE UM USUÁRIO
/addsaldo - ADICIONA SALDO AO UM USUÁRIO
/usuario - PESQUISA UM USUÁRIO E ABRE UM PAINEL ADM!
""",
        reply_markup=kb,
    )