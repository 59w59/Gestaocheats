from pyrogram import Client, filters
from pyrogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup

from config import ADMINS
from database import cur, db
from utils import is_b_online


def set_b_status(statusb: bool):
    """Define o status do bot para o status definido."""

    cur.execute("UPDATE bot_config SET is_on = ? WHERE ROWID = 0", (statusb,))
    db.commit()


@Client.on_callback_query(filters.regex("^b_status$"))
async def b_status(c: Client, m: CallbackQuery):
    is_b = is_b_online()

    statusb = "✅ Ativar " if is_b else "⭕️ Desativar "
    reverseb = "⭕️ Desativar " if is_b else "✅ Ativar "

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    reverseb, callback_data="changeb_status " + reverseb.split()[-1]
                ),
            ],
            [InlineKeyboardButton("🔙 Voltar", callback_data="start")],
            
        ]
    )

    await m.edit_message_text(
        f"<b>🚦 Status da notificação do bot: </b>\n"
        "<i>- - Esta opção controla se você quer ou não receber notificações aqui no bot como avisos, promoções, entre outras coisas.</i>\n\n"
        f"<b>Status atual:</b> {statusb}",
        reply_markup=kb,
    )


@Client.on_callback_query(
    filters.regex(r"^changeb_status (?P<statusb>.+)")
)
async def changeb_status(c: Client, m: CallbackQuery):
    statusb = m.matches[0]["statusb"] == "Ativar"

    set_b_status(statusb)

    await m.answer(f"⚠️ As notificações foram alterada", show_alert=True )

    # Directly call the function again to edit callback data after the change.
    await b_status(c, m)
