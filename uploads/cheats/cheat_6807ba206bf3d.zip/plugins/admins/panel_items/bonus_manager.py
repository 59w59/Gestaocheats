import sqlite3
from pyrogram import Client, filters
from database import cur, save
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
from config import ADMINS

# Conexão com o banco de dados
con = sqlite3.connect('main.db')

# Função para configurar o valor do bônus de registro
def set_register_bonus(amount):
    cur.execute('REPLACE INTO config (key, value) VALUES (?, ?)', ('register_bonus', amount))
    save()

# Função para obter o valor do bônus de registro
def get_register_bonus():
    result = cur.execute('SELECT value FROM config WHERE key = ?', ('register_bonus',)).fetchone()
    if result:
        return int(result[0])
    return 0  # Se não houver valor, retorna 0 (bônus desativado)

# Comando para o admin definir o valor do bônus de registro
@Client.on_message(filters.command('set_bonus') & filters.user(ADMINS))  # admin_id será definido no arquivo principal
async def set_bonus(c: Client, m: Message):
    if len(m.command) < 2:
        await m.reply_text("<b>⚠️ Por favor, informe o valor do bônus. Exemplo:</b> <code>/set_bonus 10</code>")
        return
    
    try:
        bonus_value = int(m.command[1])
    except ValueError:
        await m.reply_text("<b>⚠️ O valor do bônus deve ser um número.</b>")
        return
    
    set_register_bonus(bonus_value)
    
    if bonus_value > 0:
        await m.reply_text(f"<b>✅ Bônus de registro definido para R$ {bonus_value} reais.</b>")
    else:
        await m.reply_text("<b>✅ Bônus de registro desativado.</b>")

save()