import io
from typing import Union

import sqlite3
from pyrogram import Client, filters
import re
from pyrogram.types import CallbackQuery
from config import ADMINS
from database import cur, save
import csv
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# Variável para armazenar o estado de espera do BIN
awaiting_bin = {}

  
def export_cards_to_file(file_path='cards.txt'):
    conn = sqlite3.connect('main.db')  # Substitua pelo caminho do seu banco de dados
    cursor = conn.cursor()
    cursor.execute("SELECT number, month, year, cvv FROM ggs")
    rows = cursor.fetchall()

    with open(file_path, 'w') as file:
        for row in rows:
            file.write('|'.join(row) + '\n')  # Junta os valores com `|` e adiciona uma nova linha

    conn.close()
    return file_path
  
def delete_all_cards():
    conn = sqlite3.connect('main.db')  # Substitua pelo caminho do seu banco de dados
    cursor = conn.cursor()
    cursor.execute("DELETE FROM ggs")
    conn.commit()
    conn.close()

app = Client("my_bot")

# Função para contar e exibir quantos cartões existem para cada BIN
@Client.on_callback_query(filters.regex(r"count_bins"))
async def on_count_bins(c: Client, m: CallbackQuery):
    conn = sqlite3.connect("main.db")
    cursor = conn.cursor()

    # Consulta para contar cartões por BIN
    cursor.execute("SELECT bin, COUNT(*) FROM ggs GROUP BY bin")
    bin_counts = cursor.fetchall()

    # Fechar a conexão com o banco de dados
    conn.close()

    # Criar a mensagem de resposta com a contagem de cartões
    if bin_counts:
        response_message = "<b>Contagem de cartões por BIN:</b>\n\n"
        response_message += "\n".join([f"BIN {bin_value}: {count} cartões" for bin_value, count in bin_counts])

        # Criar os botões
        keyboard = InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("⛔ Deletar GGs", callback_data="deletar_cartoes")],
                [InlineKeyboardButton("🌐 Baixar GGs", callback_data="baixar_cartoes")],
                [InlineKeyboardButton("🔻 Voltar", callback_data="painel")]
            ]
        )
        await m.message.edit_text(response_message, reply_markup=keyboard)
    else:
        await m.message.edit_text("Não há cartões cadastrados.")

    await m.answer()  # Fecha a notificação de callback
  
@Client.on_callback_query(filters.regex(r"^deletar_cartoes$") & filters.user(ADMINS))  # Substitua pelo seu ID de administrador
async def ask_delete_cards(c: Client, m: CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ Confirmar Deletar Todos", callback_data="confirm_delete")],
        ]
    )
    await m.edit_message_text("⚠️ Deseja deletar todos os cartões?", reply_markup=keyboard)

@Client.on_callback_query(filters.regex("confirm_delete"))
async def on_confirm_delete(client, callback_query):
    delete_all_cards()
    await callback_query.message.edit_text("Todos os cartões foram deletados com sucesso.")
    await callback_query.answer()  # Fecha a notificação de callback

@Client.on_callback_query(filters.regex(r"^baixar_cartoes$") & filters.user(ADMINS))  # Substitua pelo seu ID de administrador
async def ask_download_cards(c: Client, m: CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ Baixar Todos os Cartões", callback_data="download_cards")]
        ]
    )
    await m.edit_message_text("⚠️ Deseja baixar todos os cartões como um arquivo?", reply_markup=keyboard)

@Client.on_callback_query(filters.regex("download_cards"))
async def on_download_cards(client, callback_query):
    file_path = export_cards_to_file()
    await client.send_document(chat_id=callback_query.message.chat.id, document=file_path)
    await callback_query.answer()  # Fecha a notificação de callback

save()