import time
from typing import List
from pyrogram import Client, filters, errors
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton

from config import ADMINS
from database import cur
from utils import create_mention

@Client.on_message(filters.command(["broadcast", "enviar"]) & filters.user(ADMINS))
async def broadcast(c: Client, m: Message):
    mention = create_mention(m.from_user, with_id=False)
    
    await m.reply_text(
        "📣 Você está no <b>modo broadcast</b>, no qual você pode enviar mensagens para todos os usuários do bot.\n"
        "Por favor, envie a(s) mensagem(s) que você deseja enviar abaixo. "
        "Envie <b>/enviar</b> novamente para enviar ou <b>/cancel</b> para cancelar.",
    )

    last_msg = 0
    messages: List[Message] = []

    while True:
        msg = await c.wait_for_message(m.chat.id, filters.incoming, timeout=300)

        if msg.text:
            if msg.text.startswith("/send") or msg.text.startswith("/enviar"):
                break
            if msg.text.startswith("/cancel"):
                return await m.reply_text("✅ Comando cancelado.")
        messages.append(msg)

        # Adiciona a mensagem indicando que a mensagem foi adicionada
        await msg.reply_text(
            "✅ Mensagem adicionada. "
            "Envie mais mensagens ou digite <b>/enviar</b> para enviar ou <b>/cancel</b> para cancelar.",
            quote=True,
        )

    if not messages:
        return await m.reply_text("❕ ⚠️ Não há nada para enviar. Comando cancelado.")

    sent = await m.reply_text("📣 Enviando mensagens...")

    all_users = cur.execute(
        "SELECT username FROM users WHERE is_blacklisted = 0"
    ).fetchall()

    users_count = len(all_users)
    count = 0
    blocks = 0

    for i, user in enumerate(all_users):
        for message in messages:
            try:
                if message.poll or message.forward_from_chat:
                    await message.forward(user[0])
                elif message.photo:  # Verifica se a mensagem contém uma foto
                    await c.send_photo(
                        chat_id=user[0],
                        photo=message.photo.file_id,  # Usa o ID do arquivo da foto
                        caption=f"<b>{message.caption or ''}</b>"
                    )
                else:
                    # Adiciona a menção do usuário à mensagem antes de enviar, pulando duas linhas
                    text_with_mention = f"<b>{message.text}</b>"
                    await c.send_message(
                        chat_id=user[0],
                        text=text_with_mention
                    )
            except errors.exceptions.bad_request_400.UserIsBlocked:
                blocks += 1
            except Exception as e:
                print(e)
            else:
                count += 1

        if time.time() - last_msg > 3:
            last_msg = time.time()
            try:
                await sent.edit_text(
                    f"📣 Enviando mensagem... {(i / users_count) * 100:.2f}% concluído."
                )
            except:
                pass

    await sent.edit_text(
        f"""<b>Receberam: {users_count}</b>"""
    )
    