import sqlite3
from datetime import datetime, timedelta
from pyrogram import Client, filters
from config import ADMINS
from database import cur, save


# Função para gerar o relatório
async def gerar_relatorio():
    # Conectando ao banco de dados
    conn = sqlite3.connect('main.db')
    cursor = conn.cursor()

    # Datas para filtragem
    hoje = datetime.now().date()
    sete_dias_atras = hoje - timedelta(days=7)
    quinze_dias_atras = hoje - timedelta(days=15)

    # Relatório de hoje
    cur.execute("""
    SELECT SUM(value) FROM sold_balance WHERE date(add_balance_date) = ? AND type = 'auto'
    """, (hoje,))
    total_pix_hoje = cur.fetchone()[0] or 0

    cur.execute("""
    SELECT COUNT(*) FROM sold_balance WHERE date(add_balance_date) = ? AND type = 'cards'
    """, (hoje,))
    total_cartoes_hoje = cur.fetchone()[0]

    cur.execute("""
    SELECT SUM(value) FROM sold_balance WHERE date(add_balance_date) = ? AND type = 'manual'
    """, (hoje,))
    total_gifts_hoje = cur.fetchone()[0] or 0

    # Relatório últimos 7 dias
    cur.execute("""
    SELECT SUM(value) FROM sold_balance WHERE date(add_balance_date) BETWEEN ? AND ? AND type = 'auto'
    """, (sete_dias_atras, hoje))
    total_pix_7_dias = cur.fetchone()[0] or 0

    cur.execute("""
    SELECT COUNT(*) FROM sold_balance WHERE date(add_balance_date) BETWEEN ? AND ? AND type = 'cards'
    """, (sete_dias_atras, hoje))
    total_cartoes_7_dias = cur.fetchone()[0]

    cur.execute("""
    SELECT SUM(value) FROM sold_balance WHERE date(add_balance_date) BETWEEN ? AND ? AND type = 'manual'
    """, (sete_dias_atras, hoje))
    total_gifts_7_dias = cur.fetchone()[0] or 0

    # Relatório últimos 15 dias
    cur.execute("""
    SELECT SUM(value) FROM sold_balance WHERE date(add_balance_date) BETWEEN ? AND ? AND type = 'auto'
    """, (quinze_dias_atras, hoje))
    total_pix_15_dias = cur.fetchone()[0] or 0

    cur.execute("""
    SELECT COUNT(*) FROM sold_balance WHERE date(add_balance_date) BETWEEN ? AND ? AND type = 'cards'
    """, (quinze_dias_atras, hoje))
    total_cartoes_15_dias = cur.fetchone()[0]

    cur.execute("""
    SELECT SUM(value) FROM sold_balance WHERE date(add_balance_date) BETWEEN ? AND ? AND type = 'manual'
    """, (quinze_dias_atras, hoje))
    total_gifts_15_dias = cur.fetchone()[0] or 0

    save()
    # Fechando a conexão
    conn.close()

    # Formatação do relatório
    relatorio = (
        f"📊 Relatório de transações:\n\n"
        f"🔹 <b>Hoje:</b>\n"
        f"- Total Pix: R$ {total_pix_hoje / 100:.2f}\n"
        f"- Cartões vendidos: {total_cartoes_hoje}\n"
        f"- Gifts resgatados: R$ {total_gifts_hoje:.2f}\n\n"
        f"🔹 <b>Últimos 7 dias:</b>\n"
        f"- Total Pix: R$ {total_pix_7_dias:.2f}\n"
        f"- Cartões vendidos: {total_cartoes_7_dias}\n"
        f"- Gifts resgatados: R$ {total_gifts_7_dias:.2f}\n\n"
        f"🔹 <b>Últimos 15 dias:</b>\n"
        f"- Total Pix: R$ {total_pix_15_dias / 100:.2f}\n"
        f"- Cartões vendidos: {total_cartoes_15_dias}\n"
        f"- Gifts resgatados: R$ {total_gifts_15_dias:.2f}\n"
    )
    
    return relatorio

    save()
  
# Comando para enviar o relatório no bot
@Client.on_message(filters.command("relatorio") & filters.user(ADMINS))  # Substitua admin_id pelo ID do admin
async def enviar_relatorio(client, message):
    relatorio = await gerar_relatorio()
    await message.reply_text(relatorio)