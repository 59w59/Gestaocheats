from pyrogram import Client, filters
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
    Message,
)

import random
import string
import urllib.parse

from config import ADMIN_CHAT, ADMINS, GIFTERS, LOG_CHAT
from database import cur, save


def gift_generator(size=12, chars=string.ascii_uppercase + string.digits):
    return "".join(random.choices(chars, k=size))


GIFT_MSG = """<b>🏷 GIFT CARD GERADO!</b>
<b>GIFT CARD: </b><code>/resgatar {gift}</code>
<b>VALOR: R$ {value}</b>
<b>RESGATE: @{bot_username}</b>
"""


@Client.on_message(
    filters.regex(r"^/gift (?P<value>-?\d+)") & (filters.user(ADMINS) | filters.user(GIFTERS))
)
async def create_gift(c: Client, m: Message):
    value = int(m.matches[0]["value"])
    gift = gift_generator()

    cur.execute("INSERT INTO gifts(token, value) VALUES(?, ?)", [gift, value])
    save()

    await m.reply_text(
        GIFT_MSG.format(value=value, gift=gift, bot_username=c.me.username)
    )

    text = f""
    await c.send_message(LOG_CHAT, text)

@Client.on_message(
    filters.command("donategift") & (filters.user(ADMINS) | filters.user(GIFTERS))
)
async def create_gifts(c: Client, m: Message):
    try:
        # Verifica se o comando foi digitado corretamente
        if len(m.command) != 2:
            await m.reply("<i>⚠️ Use o comando corretamente: /donategift valor</i>")
            return

        num_gifts = 5  # Número de gifts a serem gerados
        value = int(m.command[1])  # Valor do gift fornecido pelo usuário

        gifts = [
            (gift_generator(), value) for _ in range(num_gifts)
        ]  # Lista de tuples contendo gifts e valores

        # Insere todos os gifts no banco de dados
        cur.executemany(
            "INSERT INTO gifts(token, value) VALUES(?, ?)", gifts
        )
        save()

        # Cria uma única mensagem com todas as informações dos gifts
        gifts_info = "\n".join(
            GIFT_MSG.format(value=value, gift=gift, bot_username=c.me.username)
            for gift, value in gifts
        )

        await m.reply_text(gifts_info)

        text = f"<i>🎁 {num_gifts} gifts de R$ {value} foram gerados.</i>"
        await c.send_message(LOG_CHAT, text)
    except ValueError:
        await m.reply("<i>⚠️ O valor fornecido deve ser um número válido.</i>")
    except Exception as e:
        await m.reply(f"<i>❌ Ocorreu um erro ao processar sua solicitação: {str(e)}</i>")

@Client.on_inline_query(
    filters.regex(r"^gift (?P<value>-?\d+)") & (filters.user(ADMINS) | filters.user(GIFTERS))
)
async def create_gift_inline(c: Client, m: InlineQuery):
    value = int(m.matches[0]["value"])
    gift = gift_generator()

    cur.execute("INSERT INTO gifts(token, value) VALUES(?, ?)", [gift, value])
    save()

    share_text = f"🏷 **GIFT CARD GERADO!**\n\n**GIFT CARD:** `/resgatar {gift}`\n**VALOR:** R$ {value}\n**RESGATE:** @{c.me.username}"
    share_text_encoded = urllib.parse.quote_plus(share_text)
    share_link = f"https://t.me/share/url?url=&text={share_text_encoded}"

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
               InlineKeyboardButton("Compartilhar", url=share_link)
            ],
        ]
    )

    results = [
        InlineQueryResultArticle(
            title=f"Gift de R$ {value} criado",
            description="Clique para compartilhar o gift.",
            input_message_content=InputTextMessageContent(
                GIFT_MSG.format(value=value, gift=gift, bot_username=c.me.username)
            ),
            reply_markup=kb,
        )
    ]

    await m.answer(results, cache_time=0, is_personal=True)

    text = f""
    await c.send_message(ADMIN_CHAT, text)
