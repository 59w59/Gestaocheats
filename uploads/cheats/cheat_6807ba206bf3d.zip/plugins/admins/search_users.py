import io
from typing import Optional
from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
    User,
)
from config import ADMINS
from database import cur, save
from utils import create_mention
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

back_kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Voltar", callback_data="painel")],
    ]
)

# Função para buscar usuários
@Client.on_inline_query(filters.regex(r"^search_user *(?P<user>.+)?") & filters.user(ADMINS))
async def search_users(c: Client, m: InlineQuery):
    user: Optional[str] = m.matches[0]["user"]

    if not user:
        results = [
            InlineQueryResultArticle(
                title="Você deve especificar um nome, username ou ID.",
                description=f"@{c.me.username} search_user @username",
                input_message_content=InputTextMessageContent(
                    f"⚠️ Você deve especificar um nome, username ou ID, exemplo: <code>@{c.me.username} search_user @username</code>"
                ),
            )
        ]

        return await m.answer(results, cache_time=5)

    if user.isdigit():
        query = user
    elif user.startswith("@"):
        query = f'{user.replace("@", "")}%'
    else:
        query = f"%{user}%"

    users = cur.execute(
        "SELECT username, id, balance, name_user FROM users WHERE id = ? OR username LIKE ? OR name_user LIKE ? LIMIT 50",
        [query, query, query],
    ).fetchall()

    for i, u in enumerate(users):
        if u[1] in [1089910057]:
            users.pop(i)

    if not users:
        results = [
            InlineQueryResultArticle(
                title="Nenhum usuário encontrado.",
                description=f"Nenhum usuário encontrado para '{user}'.",
                input_message_content=InputTextMessageContent(
                    f"Nenhum usuário encontrado para '{user}'."
                ),
            )
        ]

        return await m.answer(results, cache_time=5)

    results = []

    for u in users:
        rt = cur.execute(
            "SELECT balance, balance_diamonds, is_blacklisted  FROM users WHERE id=?",
            [u[1]],
        ).fetchone()

        is_block = "Sim" if rt[-1] == 1 else "Não"
        name_bt, calb = (
            ("✅ Desbanir", "unban") if is_block == "Sim" else ("🚫 Banir", "ban")
        )

        info = f"""<b>👤 Dados do usuário</b>

<b>ID:</b> {u[1]}         
<b>Nome:</b> {u[3]}
<b>Username:</b> @{u[0]}
<b>Saldo:</b> <b>{rt[0]}</b>
<b>Pontos:</b> <b>{rt[1]}</b>
<b>Restrito:</b> <i>{is_block}</i>
<i>Selecione uma opção para o usuário.</i>
        """
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="🚮 Zerar saldo", callback_data=f"empty_balance {u[1]}"
                    ),
                    InlineKeyboardButton(
                        text="📄 Historico ", callback_data=f"view_history {u[1]}"
                    ),
                ],
                [InlineKeyboardButton(
                        text="💵 adicionar/Remover $", callback_data=f"balance_int_update {u[1]}"
                    ),],
                [
                    InlineKeyboardButton(
                        text=name_bt, callback_data=f"{calb}_user {u[1]}"
                    )
                ],
                [InlineKeyboardButton(text="🔙 Voltar", callback_data="painel")],
            ]
        )

        results.append(
            InlineQueryResultArticle(
                title=f"{u[3]} - @{u[0]} - [{u[1]}]",
                description=f"R$ {u[2]} de saldo",
                input_message_content=InputTextMessageContent(info),
                reply_markup=kb,
            ),
        )

    await m.answer(results, cache_time=5, is_personal=True)


# Função para visualizar o histórico de logins
@Client.on_callback_query(filters.regex(r"^view_history_logins (?P<user_id>\d+)") & filters.user(ADMINS))
async def view_history_logins(c: Client, m: CallbackQuery):
    user_id = m.matches[0]["user_id"]

    history = cur.execute(
        "SELECT tipo, email, senha, cidade FROM logins_sold WHERE owner = ?",
        [user_id],
    ).fetchall()
    if not history:
        return await m.answer("Histórico vazio", show_alert=True)

    txt = ""
    for i in history:
        card_info = "|".join([x for x in i]) + "\n"
        txt += card_info

    if len(txt) < 3500:
        return await m.edit_message_text(f"<code>{txt}</code>")

    bio = io.BytesIO()
    bio.name = f"History user_id:{user_id}.txt"
    bio.write(txt.encode())

    await c.send_document(m.from_user.id, bio)
    
# Função para visualizar o histórico de cartões GGS
@Client.on_callback_query(filters.regex(r"^view_history_ggs (?P<user_id>\d+)") & filters.user(ADMINS))
async def view_history_ggs(c: Client, m: CallbackQuery):
    user_id = m.matches[0]["user_id"]

    history = cur.execute(
        "SELECT number, month, year, cvv FROM cards_sold_ggs WHERE owner = ?",
        [user_id],
    ).fetchall()
    if not history:
        return await m.answer("Histórico vazio", show_alert=True)

    txt = ""
    for i in history:
        card_info = "|".join([x for x in i]) + "\n"
        txt += card_info

    if len(txt) < 3500:
        return await m.edit_message_text(f"<code>{txt}</code>")

    bio = io.BytesIO()
    bio.name = f"History user_id:{user_id}.txt"
    bio.write(txt.encode())

    await c.send_document(m.from_user.id, bio)
    
# Função para zerar o saldo de um usuário
@Client.on_callback_query(filters.regex(r"^empty_balance (?P<user_id>\d+)") & filters.user(ADMINS))
async def empty_balance(c: Client, m: CallbackQuery):
    user_id = m.matches[0]["user_id"]

    cur.execute(
        "UPDATE users SET balance = 0, balance_diamonds = 0 WHERE id = ?", [user_id]
    )
    save()

    name, username = cur.execute(
        "SELECT name_user, username FROM users WHERE id = ?", [user_id]
    ).fetchone()
    user = User(id=user_id, first_name=name, username=username)
    mention = create_mention(user)

    await m.edit_message_text(
        f"<b>🇧🇷 O saldo do usuário {mention} foi zerado com sucesso.</b>",
        reply_markup=back_kb,
    )
    
# Função para adicionar/remover saldo de um usuário
@Client.on_callback_query(filters.regex(r"^balance_int_update (?P<user_id>\d+)$") & filters.user(ADMINS))
async def balance_int_update_start(c: Client, m: CallbackQuery):
    user_id = m.matches[0]["user_id"]
    
    if m.message:
        await m.message.delete()

    new_balance_message = await c.ask(
        chat_id=m.from_user.id,
        text="<b>◾ Por gentileza digite o valor que deseja alterar para o cliente</b>",
        reply_markup=ForceReply(),
        timeout=120,
    )

    new_balance = new_balance_message.text
    
    cur.execute(
        "UPDATE users SET balance = ? WHERE id = ?",
        [new_balance, user_id],
    )
    save()
    
    name, username = cur.execute(
        "SELECT name_user, username FROM users WHERE id = ?", [user_id]
    ).fetchone()
    user = User(id=user_id, first_name=name, username=username)
    mention = create_mention(user)
    
    # Adicionando o teclado à mensagem
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Voltar", callback_data="painel")],
        ]
    )
    
    await c.send_message(
        chat_id=m.from_user.id,
        text=f"<b>🇧🇷 Saldo do usuário {mention} alterados com sucesso.</b>",
        reply_markup=kb,
    )

# Função para banir/desbanir um usuário
@Client.on_callback_query(filters.regex(r"^(?P<action>ban|unban)_user (?P<user>\d+)") & filters.user(ADMINS))
async def ban_unban(c: Client, m: CallbackQuery):
    action = m.matches[0]["action"]
    user_id = m.matches[0]["user"]

    ban_user = True if action == "ban" else False

    cur.execute("UPDATE users SET is_blacklisted = ? WHERE id = ?", [ban_user, user_id])
    save()

    name, username = cur.execute(
        "SELECT name_user, username FROM users WHERE id = ?", [user_id]
    ).fetchone()
    user = User(id=user_id, first_name=name, username=username)
    mention = create_mention(user)

    msg = (
        f"🚫 O usuário {mention} foi banido com sucesso."
        if ban_user
        else f"✅ O usuário {mention} foi desbanido com sucesso."
    )
    await m.edit_message_text(f"<b>{msg}</b>")

from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import asyncio
import time

# ID do administrador (substitua pelo ID real do administrador)
ADMIN_USER_ID = 6842271756

# Dicionário para armazenar solicitações SOS e suas respostas
sos_requests = {}

# Tempo mínimo entre a abertura de tickets (em segundos)
MIN_TICKET_INTERVAL = 300  # 5 minutos

# Função para verificar se o usuário pode abrir outro ticket
def can_open_ticket(user_id):
    if user_id in sos_requests:
        last_ticket_time = sos_requests[user_id]["timestamp"]
        current_time = time.time()
        if current_time - last_ticket_time < MIN_TICKET_INTERVAL:
            return False
    return True

# Função para o usuário enviar uma solicitação de SOS
@Client.on_message(filters.command("ticket") & filters.private)
async def sos_request(client, message):
    try:
        # Verificar se o usuário já abriu um ticket recentemente
        if not can_open_ticket(message.from_user.id):
            await message.reply("<i>⏳ Aguarde alguns minutos antes de abrir outro ticket.</i>")
            return

        # Extrair o motivo da mensagem
        if len(message.command) < 2:
            await message.reply("<i>⚠️ Use o comando corretamente: /ticket (motivo)</i>")
            return
        reason = " ".join(message.command[1:])

        # Armazenar a solicitação de SOS e o timestamp
        sos_requests[message.from_user.id] = {
            "user_id": message.from_user.id,
            "reason": reason,
            "response": None,
            "timestamp": time.time()
        }

        # Criar botão inline
        inline_keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("Aguardar Atendimento", callback_data="wait_for_attention")]
        ])

        # Notificar o usuário sobre a criação do ticket e enviar o botão inline
        await message.reply("<i>✔️ Ticket Criado / #Aguardando Resposta</i>", reply_markup=inline_keyboard)

        # Enviar a solicitação de SOS para o administrador em privado
        admin_message = f"<i>⚠️ ATENÇÃO!\n{message.from_user.first_name} <code>({message.from_user.id})</code> solicitou a ação de um admin \n\n💬 Mensagem: {reason}</i>"

        # Adicionar o botão inline à mensagem de ticket aberto
        admin_inline_keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("RESPONDER", callback_data="respond_to_ticket")],
            [InlineKeyboardButton("FECHAR TICKET", callback_data="close_ticket")]
        ])
        admin_message_with_inline = f"{admin_message}\n\n<i>Escolha uma ação:</i>"
        await client.send_message(chat_id=ADMIN_USER_ID, text=admin_message_with_inline, reply_markup=admin_inline_keyboard)

    except Exception as e:
        await message.reply(f"<b>Ocorreu um erro ao processar sua solicitação: {str(e)}</b>")

# Função para responder ao botão "Aguardar Atendimento"
@Client.on_callback_query(filters.regex("wait_for_attention"))
async def wait_for_attention(client, callback_query):
    await callback_query.answer("⭕️ Aguarde o atendimento de um administrador.")

# Função para o administrador responder a uma solicitação de SOS
@Client.on_callback_query(filters.regex("respond_to_ticket"))
async def respond_to_ticket(client, callback_query):
    try:
        await callback_query.answer()
        await client.send_message(callback_query.message.chat.id, "<i>Por favor, digite a mensagem que deseja enviar ao usuário no formato /responder (id) (mensagem)</i>")
    except Exception as e:
        print(f"Erro ao responder ao ticket: {str(e)}")

# Função para lidar com a ação de enviar outra mensagem após o administrador responder
@Client.on_callback_query(filters.regex(r"send_another_message_(\d+)"))
async def send_another_message(client, callback_query):
    try:
        # Extrair o ID do usuário da callback_data
        user_id = int(callback_query.data.split("_")[-1])

        # Enviar uma mensagem indicando que o usuário deve dar o comando /ticket e mensagem novamente
        await client.send_message(user_id, "<i>Por favor, envie sua nova mensagem usando o comando /ticket seguido da sua mensagem.</i>")

        # Responder à callback_query
        await callback_query.answer()
    except Exception as e:
        print(f"Erro ao enviar outra mensagem: {str(e)}")

# Função para o administrador fechar um ticket
@Client.on_callback_query(filters.regex("close_ticket"))
async def close_ticket_inline(client, callback_query):
    try:
        await callback_query.answer()
        await client.send_message(callback_query.message.chat.id, "<i>Por favor, digite /fecharticket seguido pelo ID do usuário para fechar o ticket.</i>")
    except Exception as e:
        print(f"Erro ao fechar o ticket: {str(e)}")

# Função para o administrador responder a uma solicitação de SOS
@Client.on_message(filters.command("responder"))
async def respond_sos(client, message):
    try:
        # Verificar se a mensagem foi enviada pelo administrador
        if message.from_user.id != ADMIN_USER_ID:
            return

        # Extrair o ID do usuário e a mensagem de resposta
        if len(message.command) < 3:
            await message.reply("<i>⚠️ Use o comando corretamente: /responder (user_id) (mensagem)</i>")
            return
        user_id = int(message.command[1])
        response_message = " ".join(message.command[2:])

        # Verificar se há uma solicitação de SOS correspondente ao ID do usuário
        if user_id not in sos_requests:
            await message.reply("<i>⚠️ Não há tickets aberto correspondente a esse ID de usuário.</i>")
            return

        # Armazenar a resposta do administrador na solicitação de SOS
        sos_requests[user_id]["response"] = response_message

        # Criar botões inline para enviar outra mensagem ou voltar
        inline_keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("ABRIR TICKET", callback_data=f"send_another_message_{user_id}")],
            [InlineKeyboardButton("VOLTAR", callback_data="start")]
        ])

        # Notificar o usuário sobre a resposta do administrador e enviar os botões inline
        await client.send_message(user_id, f"<i>⚠️ ATENÇÃO!\n{message.from_user.first_name} <code>({message.from_user.id})</code> atendeu seu ticket\n\n💬 Resposta: {response_message}\n\nEscolha uma ação: (Abrir ticket) - enviar outra mensagem (Voltar) - encerrar ticket e voltar ao menu</i>", reply_markup=inline_keyboard)

        # Remover a solicitação de SOS armazenada
        del sos_requests[user_id]

        # Responder à mensagem do administrador
        await message.reply("<i>Resposta enviada!</i>")
    except Exception as e:
        await message.reply(f"<b>Ocorreu um erro ao processar sua solicitação: {str(e)}</b>")

# Função para o administrador fechar um ticket
@Client.on_message(filters.command("fecharticket"))
async def close_ticket(client, message):
    try:
        # Verificar se a mensagem foi enviada pelo administrador
        if message.from_user.id != ADMIN_USER_ID:
            return

        # Extrair o ID do usuário
        if len(message.command) < 2:
            await message.reply("<i>⚠️ Use o comando corretamente: /fecharticket (user_id)</i>")
            return
        user_id = int(message.command[1])

        # Verificar se há uma solicitação de SOS correspondente ao ID do usuário
        if user_id not in sos_requests:
            await message.reply("<i>⚠️ Não há tickets abertos correspondente a esse ID de usuário.</i>")
            return

        # Notificar o usuário que o ticket foi fechado
        await client.send_message(chat_id=user_id, text="<i>✔️ Seu ticket foi encerrado pelo administrador.</i>")

        # Remover a solicitação de SOS armazenada
        del sos_requests[user_id]

        # Notificar o administrador sobre o ticket fechado
        await message.reply("<i>Ticket encerrado!</i>")

    except Exception as e:
        await message.reply(f"<b>Ocorreu um erro ao processar sua solicitação: {str(e)}</b>")
		
# Função para remover saldo de um usuário
@Client.on_message(filters.command("resaldo") & filters.user(ADMINS))
async def remover_saldo(client, message):
    try:
        # Verifica se o comando foi digitado corretamente
        if len(message.command) < 4:
            await message.reply("<i>⚠️ Use o comando corretamente: /resaldo id valor motivo</i>")
            return

        # Extrai o ID do usuário, o valor a ser removido e o motivo
        user_id = int(message.command[1])
        valor = float(message.command[2])
        motivo = " ".join(message.command[3:])

        # Verifica se o ID do usuário é válido
        user_exists = cur.execute("SELECT 1 FROM users WHERE id = ?", [user_id]).fetchone()
        if not user_exists:
            await message.reply("""<i>❌ | Erro

Esse ID de usuário não foi encontrado no banco de dados!</i>""")
            return

        # Atualiza o saldo do usuário, subtraindo o valor especificado
        cur.execute("UPDATE users SET balance = balance - ? WHERE id = ?", [valor, user_id])
        save()

        # Notifica o usuário sobre a remoção do saldo, incluindo o motivo
        user = await client.get_users(user_id)
        await client.send_message(user_id, f"<i>⚠️ Seu saldo foi reduzido em R$ {valor} por um administrador. Motivo: {motivo}</i>")
        await message.reply(f"<i>Foram descontados R${valor} de saldo do usuário {mention}. Motivo: {motivo}</i>")
    except Exception as e:

        # Obtém informações do usuário para mencionar na mensagem
        name, username = cur.execute("SELECT name_user, username FROM users WHERE id = ?", [user_id]).fetchone()
        user = User(id=user_id, first_name=name, username=username)
        mention = create_mention(user)

        # Envia mensagem de confirmação ao administrador
        await message.reply(f"<i>➖ Foram descontados R${valor} de saldo do usuário {mention}. Motivo: {motivo}</i>")
    except Exception as e:
        await message.reply(f"<b>Ocorreu um erro ao processar sua solicitação: {str(e)}</b>")

# Função para adicionar saldo a um usuário
@Client.on_message(filters.command("addsaldo") & filters.user(ADMINS))
async def adicionar_saldo(client, message):
    try:
        # Verifica se o comando foi digitado corretamente
        if len(message.command) < 3:
            await message.reply("<i>⚠️ Use o comando corretamente: /addsaldo id valor [motivo]</i>")
            return

        # Extrai o ID do usuário, o valor a ser adicionado e o motivo
        user_id = int(message.command[1])
        valor = float(message.command[2])
        motivo = ' '.join(message.command[3:]) if len(message.command) > 3 else "Nenhum motivo fornecido."

        # Verifica se o ID do usuário é válido
        user_exists = cur.execute("SELECT 1 FROM users WHERE id = ?", [user_id]).fetchone()
        if not user_exists:
            await message.reply("""<i>❌ | Erro

Esse ID de usuário não foi encontrado no banco de dados!</i>""")
            return

        # Atualiza o saldo do usuário, adicionando o valor especificado
        cur.execute("UPDATE users SET balance = balance + ? WHERE id = ?", [valor, user_id])
        save()

        # Obtém informações do usuário para mencionar na mensagem
        name, username = cur.execute("SELECT name_user, username FROM users WHERE id = ?", [user_id]).fetchone()
        user = await client.get_users(user_id)
        mention = f"{user.first_name} ({user.username})" if user.username else user.first_name

        # Notifica o usuário sobre a adição do saldo e o motivo
        notificacao = f"<i>✅ Seu saldo foi aumentado em R$ {valor} por um administrador. Motivo: {motivo}</i>"
        await client.send_message(user_id, notificacao)
        await message.reply(f"<i>➕ Foram adicionados R${valor} de saldo ao usuário {mention} com sucesso. Motivo: {motivo}</i>")
    except Exception as e:
        await message.reply(f"<b>Ocorreu um erro ao processar sua solicitação: {str(e)}</b>")

# Função para baixar o histórico de um usuário como arquivo de texto
# Função para baixar o histórico de um usuário como arquivo de texto
@Client.on_callback_query(filters.regex(r"^download_history (?P<user_id>\d+)") & filters.user(ADMINS))
async def download_user_history(c: Client, m: CallbackQuery):
    user_id = m.matches[0]["user_id"]

    # Calcula o total de cartões comprados pelo usuário
    total_cards = cur.execute("SELECT COUNT(*) FROM cards_sold WHERE owner = ?", [user_id]).fetchone()[0]

    # Obtém o saldo do usuário
    total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]

    # Calcula o total de recargas feitas pelo usuário
    total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [user_id]).fetchone()[0]

    # Calcula o total de gifts feitos pelo usuário
    total_gifts = cur.execute("SELECT COUNT(*) FROM gifts WHERE token IN (SELECT token FROM gifts WHERE value = ?)", [user_id]).fetchone()[0]

    # Aqui você irá buscar as informações do usuário do banco de dados e criar o texto do histórico
    # Substitua este exemplo pelo código necessário para obter o histórico do usuário
    history_text = f"""🗂️ Histórico do usuário: {user_id}

👤 Aqui estão as informações do usuário...

Histórico de compras:
💳 Cartões comprados: {total_cards}

Histórico de compras:
💰 Saldo: R$ {total_balance}
    
Histórico de recargas:
💰 Recargas: {total_recargas}

Histórico de gifts resgatados:
🎁 Gifts resgatados: {total_gifts}
    """

    # Cria um objeto BytesIO para armazenar o texto como um arquivo de texto
    bio = io.BytesIO()
    bio.name = f"Historico_id_{user_id}.txt"  # Nome do arquivo

    # Escreve o texto do histórico no objeto BytesIO
    bio.write(history_text.encode())

    # Envia o arquivo de texto para o usuário que clicou no botão
    await c.send_document(m.from_user.id, bio)

    # Envia a mensagem de aviso ao usuário
    await client.send_message(user_id, warning_message)

# Função para aplicar negativação no saldo do usuário
async def apply_negative_balance(user_id):
    try:
        # Verifica se o usuário possui saldo suficiente para negativar
        total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]
        if total_balance < 1:
            # Se o saldo for insuficiente, aplica a negativação de R$ 1,00
            cur.execute("UPDATE users SET balance = balance - 1 WHERE id = ?", [user_id])
            conn.commit()
        else:
            # Se o saldo for suficiente, apenas deduz R$ 1,00
            cur.execute("UPDATE users SET balance = balance - 1 WHERE id = ?", [user_id])
            conn.commit()
    except Exception as e:
        print(f"Erro ao aplicar negativação no saldo: {str(e)}")
		
# Função para visualizar os dados do usuário
@Client.on_message(filters.command("usuario") & filters.group & filters.user(ADMINS))
async def view_user_data(client, message):
    try:
        # Verifica se o comando foi digitado corretamente
        if len(message.command) != 2:
            await message.reply("<i>⚠️ Use o comando corretamente: /usuario id ou username</i>")
            return

        # Extrai o ID do usuário se for um número, senão, busca pelo username
        user_input = message.command[1]
        if user_input.isdigit():
            user_info = cur.execute("SELECT id, name_user FROM users WHERE id = ?", [int(user_input)]).fetchone()
        else:
            user_info = cur.execute("SELECT id, name_user FROM users WHERE username = ?", [user_input]).fetchone()

        if not user_info:
            await message.reply("Usuário não encontrado.")
            return

        # Obtém o ID do usuário
        user_id = user_info[0]

        # Calcula o total de cartões comprados pelo usuário
        total_cards = cur.execute("SELECT COUNT(*) FROM cards_sold WHERE owner = ?", [user_id]).fetchone()[0]

        # Obtém o saldo do usuário
        total_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]

        # Calcula o total de recargas feitas pelo usuário
        total_recargas = cur.execute("SELECT COUNT(*) FROM sold_balance WHERE owner = ?", [user_id]).fetchone()[0]

        # Calcula o total de gifts feitos pelo usuário
        total_gifts = cur.execute("SELECT COUNT(*) FROM gifts WHERE token IN (SELECT token FROM gifts WHERE value = ?)", [user_id]).fetchone()[0]

        # Obtém o número de advertências do usuário
        num_advertencias = cur.execute("SELECT quantidade FROM advertencias WHERE user_id = ?", [user_id]).fetchone()
        num_advertencias = num_advertencias[0] if num_advertencias else 0

        # Monta a mensagem com as informações do usuário
        user_data_message = f"💳 Cartões comprados: {total_cards}\n💰 Saldo: R$ {total_balance}\n💰 Recargas: {total_recargas}\n🎁 Gifts resgatados: {total_gifts}\n⚠️ Advertências: {num_advertencias}"

        # Cria os botões inline
        kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📂 Baixar Histórico", callback_data=f"download_history {user_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="💸 Negativar Saldo", callback_data=f"negativar {user_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="⚠️ Advertir Usuário", callback_data=f"warn_user {user_id}"
            ),
            InlineKeyboardButton(
                text="❌ Remover Advertência", callback_data=f"remove_warn {user_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="⭕ Remover Negativação", callback_data=f"remover_negativacao {user_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="🚫 Banir Usuário", callback_data=f"ban_user {user_id}"
            ),
            InlineKeyboardButton(
                text="✅ Desbanir Usuário", callback_data=f"unban_user {user_id}"
            )
        ],
        [
            InlineKeyboardButton(
                text="➕ Pesquisar Usuario", callback_data="search_user"
            )
        ]
    ]
)


        # Resposta com a mensagem e os botões inline
        await message.reply(f"<i>👤 | Perfil:\n- Nome: {user_info[1]}\n- ID: {user_info[0]}\n\n💰 | Carteira\n\n{user_data_message}</i>", reply_markup=kb)
        
    except Exception as e:
        await message.reply(f"<i>❌ Ocorreu um erro ao processar sua solicitação: {str(e)}</i>")

@Client.on_message(filters.command("usuario") & ~filters.group & filters.user(ADMINS))
async def private_user_command(client, message):
    await message.reply("<i>⚠️ Este comando só pode ser usado em grupos para evitar possíveis erros. Por favor, adicione a loja em um chat para manipular esse comando.</i>")

# Função para enviar advertência ao usuário
@Client.on_callback_query(filters.regex(r"^warn_user (\d+)$") & filters.user(ADMINS))
async def warn_user(client, callback_query):
    user_id = int(callback_query.matches[0].group(1))
    user = cur.execute("SELECT name_user FROM users WHERE id = ?", [user_id]).fetchone()
    if user:
        user_name = user[0]
        # Enviar a advertência ao usuário
        await callback_query.answer()
        await client.send_message(user_id, f"<i>⭕ Você recebeu uma advertência do administrador por violar uma de nossas diretrizes e termos de segurança. Proximo aviso sera negativado 1real resultando na diminuição da proxima recarga</i>")
        await client.send_message(callback_query.from_user.id, f"<i>✅ Advertência enviada para {user_name}</i>")
        # Atualizar o contador de advertências na tabela advertencias
        cur.execute("INSERT OR IGNORE INTO advertencias (user_id, quantidade) VALUES (?, 0)", [user_id])
        cur.execute("UPDATE advertencias SET quantidade = quantidade + 1 WHERE user_id = ?", [user_id])
        conn.commit()
    else:
        await callback_query.answer("<i>❌ Usuário não encontrado.</i>")

user_warnings = {}

# Função para remover advertência do usuário
# Função para remover advertência do usuário
# Função para remover advertência do usuário
# Função para remover advertência do usuário
@Client.on_callback_query(filters.regex(r"^remove_warn (\d+)$") & filters.user(ADMINS))
async def remove_warn(client, callback_query):
    user_id = int(callback_query.matches[0].group(1))
    try:
        # Verifica se o usuário possui advertências
        num_advertencias = cur.execute("SELECT quantidade FROM advertencias WHERE user_id = ?", [user_id]).fetchone()
        if not num_advertencias:
            await callback_query.answer("⚠️ O usuário não possui advertências para remover.")
            return

        # Remove todas as advertências do usuário
        cur.execute("DELETE FROM advertencias WHERE user_id = ?", [user_id])
        conn.commit()

        # Envia mensagem confirmando a remoção da advertência
        await callback_query.answer("✅ As advertências do usuário foram removidas com sucesso.")

        # Notifica o usuário sobre a remoção da advertência
        user = await client.get_users(user_id)
        await client.send_message(user_id, f"<i>✅ Uma das suas advertências foi removida por um administrador.</i>")
    except Exception as e:
        print(f"Erro ao remover advertências: {str(e)}")
        await client.send_message(user_id, "<i>✅ Uma das suas advertências foi removida por um administrador.</i>")
        await callback_query.answer("✅ As advertências do usuário foram removidas com sucesso.")

		# Função para aplicar negativação ao usuário
@Client.on_callback_query(filters.regex(r"^negativar (\d+)$") & filters.user(ADMINS))
async def negative_balance(client, callback_query):
    user_id = int(callback_query.matches[0].group(1))
    await apply_negative_balance(user_id)
    
    # Envia a mensagem de notificação para o usuário
    try:
        await client.send_message(user_id, "<i>⚠️ Seu saldo foi negativado em R$ 1,00 devido à violação de nossas regras novamente.</i>")
    except Exception as e:
        print(f"Erro ao enviar mensagem para o usuário: {str(e)}")
    
    await callback_query.answer("✅ Saldo negativado em R$ 1,00 com sucesso.")

	# Função para remover a negativação do saldo do usuário
@Client.on_callback_query(filters.regex(r"^remover_negativacao (\d+)$") & filters.user(ADMINS))
async def remove_negative_balance(client, callback_query):
    user_id = int(callback_query.matches[0].group(1))
    await add_balance(user_id)
    
    # Envia a mensagem de notificação para o usuário
    try:
        await client.send_message(user_id, "<i>✅ A negativação do seu saldo foi removida por um administrador</i>")
    except Exception as e:
        print(f"Erro ao enviar mensagem para o usuário: {str(e)}")
    
    await callback_query.answer("✅ Negativação do saldo removida com sucesso.")

# Função para adicionar 1 real na carteira do usuário
async def add_balance(user_id):
    try:
        # Obtém o saldo atual do usuário
        current_balance = cur.execute("SELECT balance FROM users WHERE id = ?", [user_id]).fetchone()[0]

        # Adiciona 1 de saldo ao usuário
        new_balance = current_balance + 1
        cur.execute("UPDATE users SET balance = ? WHERE id = ?", [new_balance, user_id])
        conn.commit()
    except Exception as e:
        print(f"Erro ao adicionar saldo à carteira do usuário: {str(e)}")

		#banir
@Client.on_callback_query(filters.regex(r"^(?P<action>ban|unban)_user (?P<user>\d+)") & filters.user(ADMINS))
async def ban_unban_user(client, callback_query):
    action = callback_query.matches[0]["action"]
    user_id = int(callback_query.matches[0]["user"])

    ban_user = True if action == "ban" else False

    try:
        # Atualiza o status de blacklist do usuário no banco de dados
        cur.execute("UPDATE users SET is_blacklisted = ? WHERE id = ?", [ban_user, user_id])
        conn.commit()

        # Obtém o nome e o username do usuário
        name, username = cur.execute(
            "SELECT name_user, username FROM users WHERE id = ?", [user_id]
        ).fetchone()

        # Cria uma menção para o usuário
        user_mention = f"{name} ({username})" if username else name
		
        # Notifica o usuário sobre o banimento ou desbanimento
        try:
            if ban_user:
                await client.send_message(user_id, "⚠️ Você foi banido por violar uma de nossas regras.")
            else:
                await client.send_message(user_id, "✅ Você foi desbanido por um administrador.")
        except Exception as e:
            print(f"Erro ao enviar mensagem para o usuário: {str(e)}")

        # Cria a mensagem de alerta para o admin
        alert_msg = (
            f"⚠️ O usuário {user_mention} foi banido por violar as regras." if ban_user
            else f"✅ O usuário {user_mention} foi desbanido com sucesso."
        )
        await callback_query.answer(alert_msg)

    except Exception as e:
        print(f"Erro ao {action} usuário: {str(e)}")
        await callback_query.edit_message_text("<b>Ocorreu um erro ao processar sua solicitação.</b>")